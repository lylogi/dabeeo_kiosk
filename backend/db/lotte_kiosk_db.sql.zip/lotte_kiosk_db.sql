-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 24, 2023 at 02:12 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lotte_kiosk_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) NOT NULL,
  `map_cat_id` varchar(100) NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`title`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent_code` varchar(100) DEFAULT NULL,
  `sort_order` varchar(2) NOT NULL,
  `children_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `map_cat_id`, `title`, `created_at`, `parent_code`, `sort_order`, `children_count`) VALUES
(299, '01', '{\"en\":\"Korean food\",\"vi\":\"Ẩm thực Hàn Quốc\"}', '2023-06-24 12:03:35', '001', '1', 0),
(300, '02', '{\"en\":\"Japan food\",\"vi\":\"Ẩm thực Nhật Bản\"}', '2023-06-24 12:03:35', '001', '2', 0),
(301, '03', '{\"en\":\"Chinese food\",\"vi\":\"Ẩm thực Trung Hoa\"}', '2023-06-24 12:03:35', '001', '3', 0),
(302, '04', '{\"en\":\"Western food\",\"vi\":\"Ẩm thực phương tây\"}', '2023-06-24 12:03:35', '001', '4', 0),
(303, '05', '{\"en\":\"Asian food\",\"vi\":\"Ẩm thực Châu Á\"}', '2023-06-24 12:03:35', '001', '5', 0),
(304, '06', '{\"en\":\"Cafe \",\"vi\":\"Quán cà phê\"}', '2023-06-24 12:03:35', '001', '6', 0),
(305, '08', '{\"en\":\"Bakery/Dessert\",\"vi\":\"Bánh mì/Tráng miệng\"}', '2023-06-24 12:03:35', '001', '8', 0),
(306, '07', '{\"en\":\"Food court\",\"vi\":\"Khu ẩm thực\"}', '2023-06-24 12:03:35', '001', '7', 0),
(308, '10', '{\"en\":\"Lounge\",\"vi\":\"Dịch vụ CSKH\"}', '2023-06-24 12:03:35', '002', '2', 0),
(309, '11', '{\"en\":\"Rest room\",\"vi\":\"Nhà vệ sinh\"}', '2023-06-24 12:03:35', '002', '3', 0),
(310, '13', '{\"en\":\"Repair service\",\"vi\":\"Dịch vụ sửa đồ\"}', '2023-06-24 12:03:35', '002', '5', 0),
(311, '14', '{\"en\":\"Smoking room\",\"vi\":\"Phòng hút thuốc\"}', '2023-06-24 12:03:35', '002', '6', 0),
(312, '15', '{\"en\":\"Baby lounge\",\"vi\":\"Phòng mẹ & bé\"}', '2023-06-24 12:03:35', '002', '7', 0),
(313, '12', '{\"en\":\"Rest area\",\"vi\":\"Khu nghỉ chân\"}', '2023-06-24 12:03:35', '002', '4', 0),
(314, '16', '{\"en\":\"Medical room\",\"vi\":\"Phòng y tế\"}', '2023-06-24 12:03:35', '002', '8', 0),
(315, '09', '{\"en\":\"Information\",\"vi\":\"Quầy thông tin\"}', '2023-06-24 12:03:35', '002', '1', 0),
(316, '003', '{\"en\":\"Women fashion\",\"vi\":\"Thời trang nữ\"}', '2023-06-24 12:03:35', NULL, '3', 0),
(317, '004', '{\"en\":\"Men fashion\",\"vi\":\"Thời trang nam\"}', '2023-06-24 12:03:35', NULL, '4', 0),
(318, '005', '{\"en\":\"Young Fashion\",\"vi\":\"Thời trang trẻ\"}', '2023-06-24 12:03:35', NULL, '5', 0),
(319, '006', '{\"en\":\"Fashion accessory\",\"vi\":\"Phụ kiện thời trang\"}', '2023-06-24 12:03:35', NULL, '6', 0),
(320, '007', '{\"en\":\"Cosmetics\",\"vi\":\"Mỹ phẩm\"}', '2023-06-24 12:03:35', NULL, '7', 0),
(321, '008', '{\"en\":\"Leisure/sports\",\"vi\":\"Đồ thể thao\"}', '2023-06-24 12:03:35', NULL, '8', 0),
(322, '009', '{\"en\":\"Kids/Infants\",\"vi\":\"Đồ trẻ em\"}', '2023-06-24 12:03:35', NULL, '9', 0),
(323, '010', '{\"en\":\"Luxury fashion\",\"vi\":\"Thời trang cao cấp\"}', '2023-06-24 12:03:35', NULL, '10', 0),
(324, '011', '{\"en\":\"Living\",\"vi\":\"Đời sống\"}', '2023-06-24 12:03:35', NULL, '11', 0),
(325, '012', '{\"en\":\"Food store\",\"vi\":\"Cửa hàng thực phẩm\"}', '2023-06-24 12:03:35', NULL, '12', 0),
(326, '013', '{\"en\":\"Others\",\"vi\":\"Khác\"}', '2023-06-24 12:03:35', NULL, '13', 0),
(328, '17', '{\"en\":\"Escalator\",\"vi\":\"Thang cuốn\"}', '2023-06-24 12:03:35', '014', '1', 0),
(329, '18', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', '2023-06-24 12:03:35', '014', '2', 0),
(330, '015', '{\"en\":\"Parking\",\"vi\":\"Bãi đỗ xe\"}', '2023-06-24 12:03:35', NULL, '15', 0),
(331, '016', '{\"en\":\"Entrance\",\"vi\":\"Lối ra vào\"}', '2023-06-24 12:03:35', NULL, '16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` bigint(20) NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`title`)),
  `seq_code` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`seq_code`)),
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`content`)),
  `type` enum('promotion','event') NOT NULL DEFAULT 'event',
  `start_date` datetime NOT NULL DEFAULT current_timestamp(),
  `end_date` datetime NOT NULL DEFAULT current_timestamp(),
  `full_screen` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `title`, `seq_code`, `content`, `type`, `start_date`, `end_date`, `full_screen`, `created_at`) VALUES
(26, '{\"en\":\"Big Sale\",\"vi\":\"thời trang\"}', '{\"en\":\"6112fb6a-82a4-4efc-879d-4b384ab23958.jpg\",\"vi\":\"c36748db-e444-4d8a-82e3-210c887aadd8.jpg\"}', '{\"en\":\"Big sale \",\"vi\":\"siêu khuyến mãi lớn nhất trong năm\"}', 'promotion', '2023-06-23 10:00:00', '2023-06-28 10:00:00', 0, '2023-06-24 12:03:35');

-- --------------------------------------------------------

--
-- Table structure for table `event_poi`
--

CREATE TABLE `event_poi` (
  `event_id` bigint(20) NOT NULL,
  `poi_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) NOT NULL,
  `seq_code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('0','2') NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `seq_code`, `name`, `type`, `status`) VALUES
(748, '062cd11b-bdf8-411f-aa3a-c6bcc5e2b41c', '062cd11b-bdf8-411f-aa3a-c6bcc5e2b41c.jpg', '0', 1),
(749, 'c36748db-e444-4d8a-82e3-210c887aadd8', 'c36748db-e444-4d8a-82e3-210c887aadd8.jpg', '0', 1),
(750, '6112fb6a-82a4-4efc-879d-4b384ab23958', '6112fb6a-82a4-4efc-879d-4b384ab23958.jpg', '0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `floors`
--

CREATE TABLE `floors` (
  `id` bigint(20) NOT NULL,
  `map_floor_id` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `subject` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`subject`)),
  `order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `floors`
--

INSERT INTO `floors` (`id`, `map_floor_id`, `title`, `subject`, `order`, `created_at`) VALUES
(55, 'FL-c9ANEsq4D4206', '5F', '{\"en\":\"5F\",\"vi\":\"5F\"}', 0, '2023-06-24 12:03:35'),
(56, 'FL-ziQ3RKtohg3838', '4F', '{\"en\":\"4F\",\"vi\":\"4F\"}', 1, '2023-06-24 12:03:35'),
(57, 'FL-PKTf7H2oLJ3486', '3F', '{\"en\":\"3F\",\"vi\":\"3F\"}', 2, '2023-06-24 12:03:35'),
(58, 'FL-Q7b9m8Ly73110', '2F', '{\"en\":\"2F\",\"vi\":\"2F\"}', 3, '2023-06-24 12:03:35'),
(59, 'FL-oQ33DFwJk8835', '1F', '{\"en\":\"1F\",\"vi\":\"1F\"}', 4, '2023-06-24 12:03:35'),
(60, 'FL-2RgrriDiE1221', 'B1F', '{\"en\":\"B1F\",\"vi\":\"B1F\"}', 5, '2023-06-24 12:03:35');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `language` varchar(10) NOT NULL,
  `serialKey` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint(20) NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`title`)),
  `type` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_categories`
--

CREATE TABLE `menu_categories` (
  `menu_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pois`
--

CREATE TABLE `pois` (
  `id` bigint(20) NOT NULL,
  `map_poi_id` varchar(100) NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`title`)),
  `desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`desc`)),
  `seq_code` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`seq_code`)),
  `branch_id` bigint(20) NOT NULL,
  `coordinate_x` double NOT NULL,
  `coordinate_y` double NOT NULL,
  `phone` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`phone`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `floor_id` bigint(20) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `pois`
--

INSERT INTO `pois` (`id`, `map_poi_id`, `title`, `desc`, `seq_code`, `branch_id`, `coordinate_x`, `coordinate_y`, `phone`, `created_at`, `floor_id`, `category_id`) VALUES
(3799, 'PO-snmYn9pUq7543', '{\"en\":\"Chickita\",\"ko\":\"상점\",\"vi\":\"Chickita\"}', NULL, NULL, 10, 2543.88, 903.87, NULL, '2023-06-24 12:03:35', 55, 303),
(3800, 'PO-hx4wkAxMo1015', '{\"en\":\"Cafe INEAT\",\"ko\":\"상점\",\"vi\":\"Cafe INEAT\"}', NULL, NULL, 10, 2151.6, 1006.46, NULL, '2023-06-24 12:03:35', 55, 304),
(3801, 'PO-Sh9ZIFHr73463', '{\"en\":\"Pizza 4P\'s\",\"ko\":\"상점\",\"vi\":\"Pizza 4P\'s\"}', NULL, NULL, 10, 2747.507496975002, 1243.5950406765694, NULL, '2023-06-24 12:03:35', 55, 302),
(3802, 'PO-F5YFm232w0263', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2189.2372287904377, 1250.042370079251, NULL, '2023-06-24 12:03:35', 55, 328),
(3803, 'PO-otHBNTkPo5422', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2420.9, 1355.01, NULL, '2023-06-24 12:03:35', 55, 329),
(3804, 'PO-o6imdZR6w7415', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2420.9, 1410.01, NULL, '2023-06-24 12:03:35', 55, 329),
(3805, 'PO-HUFUYRaEj6422', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.0493680910172, 1693.286613516048, NULL, '2023-06-24 12:03:35', 55, 329),
(3806, 'PO-mk3n4y5Js8214', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 942.25, 1911.68, NULL, '2023-06-24 12:03:35', 55, 329),
(3807, 'PO-PJD-xkyBq9974', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.25, 1856.68, NULL, '2023-06-24 12:03:35', 55, 329),
(3808, 'PO-Tz1KVJZfP1726', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.25, 1911.68, NULL, '2023-06-24 12:03:35', 55, 329),
(3809, 'PO-dMzSmdhjU3518', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1287.2945784384085, 1470.2653814868472, NULL, '2023-06-24 12:03:35', 55, 328),
(3810, 'PO-spQz9_UcQ6110', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 2613.55, 851.99, NULL, '2023-06-24 12:03:35', 55, 309),
(3811, 'PO-jirO2Q5RA8038', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 2613.55, 796.99, NULL, '2023-06-24 12:03:35', 55, 309),
(3812, 'PO-gC8DbZxcG2878', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.43, 909.36, NULL, '2023-06-24 12:03:35', 55, 329),
(3813, 'PO-QqSxgPlFN4790', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.43, 964.36, NULL, '2023-06-24 12:03:35', 55, 329),
(3814, 'PO-LrDZiJ1s90591', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3589.14, 1726.58, NULL, '2023-06-24 12:03:35', 55, 329),
(3815, 'PO-eYbepiiOt6135', '{\"en\":\"KidZania\",\"ko\":\"상점\",\"vi\":\"Khu vui chơi trẻ em KidZania\"}', NULL, NULL, 10, 1704.67754189944, 1565.2817318435762, NULL, '2023-06-24 12:03:35', 55, 326),
(3816, 'PO-BXc0iHI4n0583', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 942.2, 1693.07, NULL, '2023-06-24 12:03:35', 55, 329),
(3817, 'PO-OCghtnizs3633', '{\"en\":\"Sky Park\",\"ko\":\"상점\",\"vi\":\"Công viên sân thượng Sky Park\"}', NULL, NULL, 10, 3047.918890681517, 1502.6088411480669, NULL, '2023-06-24 12:03:35', 55, 326),
(3818, 'PO-Gnu9iqp1f4492', '{\"en\":\"Champion 1250\",\"ko\":\"상점\",\"vi\":\"Champion 1250\"}', NULL, NULL, 10, 1360.84, 762.3700000000001, NULL, '2023-06-24 12:03:35', 56, 326),
(3819, 'PO-37jTs3x_m6506', '{\"en\":\"Cinema\",\"ko\":\"상점\",\"vi\":\"Rạp chiếu phim\"}', NULL, NULL, 10, 2669.793715083799, 611.5321229050273, NULL, '2023-06-24 12:03:35', 56, 326),
(3820, 'PO-Af3SXdV129186', '{\"en\":\"Duong Kitchen\",\"ko\":\"상점\",\"vi\":\"Duong Kitchen\"}', NULL, NULL, 10, 3648.176903431764, 1086.0099999999998, NULL, '2023-06-24 12:03:35', 56, 326),
(3821, 'PO-FTWot0OuK5042', '{\"en\":\"Day Dreamer\",\"ko\":\"상점\",\"vi\":\"Day Dreamer\"}', NULL, NULL, 10, 3633.754720670391, 1231.795, NULL, '2023-06-24 12:03:35', 56, 324),
(3822, 'PO-8E6q8cogZ7266', '{\"en\":\"Tiem Tap Hoa Nha May\",\"ko\":\"상점\",\"vi\":\"Tiệm Tạp Hoá Nhà May\"}', NULL, NULL, 10, 3552.297671652551, 1377.146594881961, NULL, '2023-06-24 12:03:35', 56, 324),
(3823, 'PO-W2N5VBH2_1098', '{\"en\":\"Indigo Studio\",\"ko\":\"상점\",\"vi\":\"Indigo Studio\"}', NULL, NULL, 10, 3554.155, 1518.37, NULL, '2023-06-24 12:03:35', 56, 326),
(3824, 'PO-6SSZXYLgs3994', '{\"en\":\"Nguyen Art Gallery\",\"ko\":\"상점\",\"vi\":\"Nguyen Art Gallery\"}', NULL, NULL, 10, 3505.33, 1659.5, NULL, '2023-06-24 12:03:35', 56, 324),
(3825, 'PO-ok5uNTUVL0273', '{\"en\":\"Cooked Studio\",\"ko\":\"상점\",\"vi\":\"Cooked Studio\"}', NULL, NULL, 10, 3505.33, 1841.48, NULL, '2023-06-24 12:03:35', 56, 326),
(3826, 'PO-bvm8yj58_2274', '{\"en\":\"Zo Project\",\"ko\":\"상점\",\"vi\":\"Zó Project\"}', NULL, NULL, 10, 3505.33, 1949.445, NULL, '2023-06-24 12:03:35', 56, 326),
(3827, 'PO-yjwMkuc4e8145', '{\"en\":\"Acid8\",\"ko\":\"상점\",\"vi\":\"Acid8\"}', NULL, NULL, 10, 3236.425, 1818.855, NULL, '2023-06-24 12:03:35', 56, 304),
(3828, 'PO-yo1dDFYRn0690', '{\"en\":\"Lumi Florang\",\"ko\":\"상점\",\"vi\":\"Lumi Florang\"}', NULL, NULL, 10, 3011.03340511804, 1964.888923229411, NULL, '2023-06-24 12:03:35', 56, 326),
(3829, 'PO-6tT-6qruo3034', '{\"en\":\"Crabit Notebuck\",\"ko\":\"상점\",\"vi\":\"Crabit Notebuck\"}', NULL, NULL, 10, 2864.46, 1817.2319197562213, NULL, '2023-06-24 12:03:35', 56, 324),
(3830, 'PO-6sDbNfrFH5610', '{\"en\":\"Tipsy Art\",\"ko\":\"상점\",\"vi\":\"Tipsy Art\"}', NULL, NULL, 10, 2529.76, 1767.490200609447, NULL, '2023-06-24 12:03:35', 56, 326),
(3831, 'PO-BIr6HWR6J9418', '{\"en\":\"Wulao\",\"ko\":\"상점\",\"vi\":\"Wulao\"}', NULL, NULL, 10, 2247.465, 1748.4450000000002, NULL, '2023-06-24 12:03:35', 56, 301),
(3832, 'PO-WICMz2Hou1152', '{\"en\":\"MangKorn\",\"ko\":\"상점\",\"vi\":\"MangKorn\"}', NULL, NULL, 10, 1848.5159776536311, 1806.8189106145253, NULL, '2023-06-24 12:03:35', 56, 303),
(3833, 'PO-cKiYMhhnL3042', '{\"en\":\"Haidilao\",\"ko\":\"상점\",\"vi\":\"Haidilao\"}', NULL, NULL, 10, 1387.67, 1901.195, NULL, '2023-06-24 12:03:35', 56, 301),
(3834, 'PO-W4MAlRBYH7841', '{\"en\":\"Yeun Kyung\",\"ko\":\"상점\",\"vi\":\"Yeun Kyung\"}', NULL, NULL, 10, 1129.3065083798888, 1608.24, NULL, '2023-06-24 12:03:35', 56, 299),
(3835, 'PO-_pnEQ-01Z9626', '{\"en\":\"Hanwadam\",\"ko\":\"상점\",\"vi\":\"Hanwadam\"}', NULL, NULL, 10, 1062.423268156425, 1273.787932960894, NULL, '2023-06-24 12:03:35', 56, 299),
(3836, 'PO-5NJy0HCHt1881', '{\"en\":\"Pho Ngon\\n37\",\"ko\":\"상점\",\"vi\":\"Phố Ngon\\n37\"}', NULL, NULL, 10, 1447.165223463687, 1375.975, NULL, '2023-06-24 12:03:35', 56, 303),
(3837, 'PO-NfWVHNPfK3890', '{\"en\":\"OGAWA\",\"ko\":\"상점\",\"vi\":\"OGAWA\"}', NULL, NULL, 10, 1538.875, 1176.8000000000002, NULL, '2023-06-24 12:03:35', 56, 324),
(3838, 'PO-qY4BwdHt76075', '{\"en\":\"Pure de \\nPet\",\"ko\":\"상점\",\"vi\":\"Pure de \\nPet\"}', NULL, NULL, 10, 1662.56, 1126.8000000000002, NULL, '2023-06-24 12:03:35', 56, 326),
(3839, 'PO-18ZstMan19689', '{\"en\":\"Audrey Nail\",\"ko\":\"상점\",\"vi\":\"Audrey Nail\"}', NULL, NULL, 10, 1758.8184296818074, 1085.9535742045182, NULL, '2023-06-24 12:03:35', 56, 326),
(3840, 'PO-VqTBqEVu-1722', '{\"en\":\"LEEKAJA Hair\",\"ko\":\"상점\",\"vi\":\"LEEKAJA Hair\"}', NULL, NULL, 10, 1871.191445227108, 1123.4555780908431, NULL, '2023-06-24 12:03:35', 56, 326),
(3841, 'PO--4np6e9FE6570', '{\"en\":\"Crystal Jade HK\",\"ko\":\"상점\",\"vi\":\"Crystal Jade HK\"}', NULL, NULL, 10, 1780.1800000000003, 1459.963096568236, NULL, '2023-06-24 12:03:35', 56, 301),
(3842, 'PO-seVzzHypp8586', '{\"en\":\"DOZO Sushi\",\"ko\":\"상점\",\"vi\":\"DOZO Sushi\"}', NULL, NULL, 10, 2064.386403220506, 1334.805, NULL, '2023-06-24 12:03:35', 56, 300),
(3843, 'PO-uzrkole-R0523', '{\"en\":\"Royce\",\"ko\":\"상점\",\"vi\":\"Royce\"}', NULL, NULL, 10, 2037.275, 1123.69, NULL, '2023-06-24 12:03:35', 56, 325),
(3844, 'PO-Ym1WXrTz54490', '{\"en\":\"Boost Juice\",\"ko\":\"상점\",\"vi\":\"Boost Juice\"}', NULL, NULL, 10, 2037.275, 1040.2399999999998, NULL, '2023-06-24 12:03:35', 56, 304),
(3845, 'PO-phw3fPdp32554', '{\"en\":\"Swensen\",\"ko\":\"상점\",\"vi\":\"Swensen\"}', NULL, NULL, 10, 2596.205, 1034.645, NULL, '2023-06-24 12:03:35', 56, 305),
(3846, 'PO-da3QoXmq64362', '{\"en\":\"GoodTime Burger\",\"ko\":\"상점\",\"vi\":\"GoodTime Burger\"}', NULL, NULL, 10, 2594.95306994116, 1103.3726294704336, NULL, '2023-06-24 12:03:35', 56, 302),
(3847, 'PO-Ubp6x3oGy6186', '{\"en\":\"llaollao\",\"ko\":\"상점\",\"vi\":\"llaollao\"}', NULL, NULL, 10, 2563.855, 1169.055, NULL, '2023-06-24 12:03:35', 56, 305),
(3848, 'PO-o3gmw-ReL7769', '{\"en\":\"Nha Nam Bookstore\",\"ko\":\"상점\",\"vi\":\"Nhà sách Nhã Nam\"}', NULL, NULL, 10, 2851.1749092350706, 1420.6548318240625, NULL, '2023-06-24 12:03:35', 56, 324),
(3849, 'PO-HcCJYU2gg9650', '{\"en\":\"Lotteria\",\"ko\":\"상점\",\"vi\":\"Lotteria\"}', NULL, NULL, 10, 2859.83, 1102.88, NULL, '2023-06-24 12:03:35', 56, 302),
(3850, 'PO-s1Bv1UFbm1673', '{\"en\":\"YUJ Pilates\",\"ko\":\"상점\",\"vi\":\"YUJ Pilates\"}', NULL, NULL, 10, 3156.1890223463683, 1178.5504469273742, NULL, '2023-06-24 12:03:35', 56, 326),
(3851, 'PO-ptbjeM3E90966', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 925.8600000000004, 1704.10408326473, NULL, '2023-06-24 12:03:35', 56, 329),
(3852, 'PO-t2BQrpHYf4670', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 980.86, 1702.34, NULL, '2023-06-24 12:03:35', 56, 329),
(3853, 'PO-akfVK4jke7054', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 980.86, 1803.57, NULL, '2023-06-24 12:03:35', 56, 329),
(3854, 'PO-stutGSoIL9070', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 980.86, 1858.57, NULL, '2023-06-24 12:03:35', 56, 329),
(3855, 'PO-tbN_5ZRvd0645', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 925.86, 1858.57, NULL, '2023-06-24 12:03:35', 56, 329),
(3856, 'PO-NC7h67cMn5925', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1256.0593760558345, 1436.4939997923882, NULL, '2023-06-24 12:03:35', 56, 328),
(3857, 'PO-l8QAPA_hN9461', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1648.6969496066602, 952.5045616235316, NULL, '2023-06-24 12:03:35', 56, 328),
(3858, 'PO-XPTI4a2cM3037', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2342.7268517614957, 1099.4554185797197, NULL, '2023-06-24 12:03:35', 56, 328),
(3859, 'PO-9hz_7Vfoj5285', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2169.122227796147, 1222.2141831034094, NULL, '2023-06-24 12:03:35', 56, 328),
(3860, 'PO--EvygHJGS2789', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 1801.26, 1286.08, NULL, '2023-06-24 12:03:35', 56, 309),
(3861, 'PO-76X0dfdtF5821', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 1801.26, 1341.08, NULL, '2023-06-24 12:03:35', 56, 309),
(3862, 'PO-y-dpHemnj5438', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 1909.16, 1286.08, NULL, '2023-06-24 12:03:35', 56, 312),
(3863, 'PO-qBGW0fXlc9454', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2420.9, 1365.7, NULL, '2023-06-24 12:03:35', 56, 329),
(3864, 'PO-9AwHNUT6c1981', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2420.9, 1420.7, NULL, '2023-06-24 12:03:35', 56, 329),
(3865, 'PO-4P6YRXEKY8462', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 2971.84, 1322.99, NULL, '2023-06-24 12:03:35', 56, 309),
(3866, 'PO--dEpIzl0f0734', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 2971.84, 1267.99, NULL, '2023-06-24 12:03:35', 56, 309),
(3867, 'PO-VorT-U6Da7846', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3534.25, 930.3, NULL, '2023-06-24 12:03:35', 56, 329),
(3868, 'PO-HUubRr4Gv9806', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3589.25, 930.3, NULL, '2023-06-24 12:03:35', 56, 329),
(3869, 'PO-HUNOHFK3X3606', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3660.43, 880.3, NULL, '2023-06-24 12:03:35', 56, 329),
(3870, 'PO-Uv8EIl1np5334', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3660.43, 825.3, NULL, '2023-06-24 12:03:35', 56, 329),
(3871, 'PO-L8Lv73bD61166', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3660.43, 770.3, NULL, '2023-06-24 12:03:35', 56, 311),
(3872, 'PO-SlBu46n6P7333', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 3660.43, 660.3, NULL, '2023-06-24 12:03:35', 56, 309),
(3873, 'PO-KmwPlYFKZ9325', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 3660.43, 715.3, NULL, '2023-06-24 12:03:35', 56, 309),
(3874, 'PO-3RKI8U0Kk8669', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3387.669824173511, 1450.3176282412835, NULL, '2023-06-24 12:03:35', 56, 328),
(3875, 'PO-KJYEpL9uq5037', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3648.31, 1706.48, NULL, '2023-06-24 12:03:35', 56, 311),
(3876, 'PO-wCuK1GJKB8165', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3648.31, 1811.48, NULL, '2023-06-24 12:03:35', 56, 329),
(3877, 'PO-vnbiHalFm0261', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3648.31, 1866.48, NULL, '2023-06-24 12:03:35', 56, 329),
(3878, 'PO-C6-FPd_302549', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3648.31, 1921.48, NULL, '2023-06-24 12:03:35', 56, 329),
(3879, 'PO-6H9U7NoPM7469', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2628.3387474114284, 1607.2188895862787, NULL, '2023-06-24 12:03:35', 56, 328),
(3880, 'PO-FyBjZn9p20631', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 1909.16, 1341.08, NULL, '2023-06-24 12:03:35', 56, 313),
(3881, 'PO-fHSvu2VUL8748', '{\"en\":\"Bonchon\",\"ko\":\"상점\",\"vi\":\"Bonchon\"}', NULL, NULL, 10, 817.8263925337276, 943.4979532433928, NULL, '2023-06-24 12:03:35', 57, 299),
(3882, 'PO-ogD8SrYui0218', '{\"en\":\"Dookki\",\"ko\":\"상점\",\"vi\":\"Dookki\"}', NULL, NULL, 10, 1063.1999999999998, 714.8140186656807, NULL, '2023-06-24 12:03:35', 57, 299),
(3883, 'PO-bKVplek2j1882', '{\"en\":\"Surah (Korean \\ntraditional \\nfine dining)\",\"ko\":\"상점\",\"vi\":\"Surah (Đồ ăn \\ntruyền thống\\n Hàn Quốc)\"}', NULL, NULL, 10, 944.0209818206577, 1121.6412272758223, NULL, '2023-06-24 12:03:35', 57, 299),
(3884, 'PO-EdpB2d5sD3370', '{\"en\":\"Surah (Korean \\nsnack)\",\"ko\":\"상점\",\"vi\":\"Surah (Đồ ăn vặt \\nHàn Quốc)\"}', NULL, NULL, 10, 1081.39, 1165.955, NULL, '2023-06-24 12:03:35', 57, 299),
(3885, 'PO-CSqjVomwH4754', '{\"en\":\"GOGI HOUSE\",\"ko\":\"상점\",\"vi\":\"GOGI HOUSE\"}', NULL, NULL, 10, 1036.957542043984, 1353.845, NULL, '2023-06-24 12:03:35', 57, 299),
(3886, 'PO-LZtbDPco-6090', '{\"en\":\"Leechadol\",\"ko\":\"상점\",\"vi\":\"Leechadol\"}', NULL, NULL, 10, 1057.7540186656804, 1608.278934577712, NULL, '2023-06-24 12:03:35', 57, 299),
(3887, 'PO-jO3sVYECG7425', '{\"en\":\"TINI WORLD\",\"ko\":\"상점\",\"vi\":\"Khu vui chơi trẻ em TINI WORLD\"}', NULL, NULL, 10, 1389.5152587322125, 727.2204269081499, NULL, '2023-06-24 12:03:35', 57, 326),
(3888, 'PO-8KpfdE3y50867', '{\"en\":\"My Kingdom (FS)\",\"ko\":\"상점\",\"vi\":\"My Kingdom (FS)\"}', NULL, NULL, 10, 1687.8729925301511, 608.9491964695565, NULL, '2023-06-24 12:03:35', 57, 322),
(3889, 'PO-MKnLUplJm2586', '{\"en\":\"Copenhagen Delights\",\"ko\":\"상점\",\"vi\":\"Copenhagen Delights\"}', NULL, NULL, 10, 1742.575, 771.365, NULL, '2023-06-24 12:03:35', 57, 322),
(3890, 'PO-lLv_Cp9o44314', '{\"en\":\"Okaidi Obaibi\",\"ko\":\"상점\",\"vi\":\"Okaidi Obaibi\"}', NULL, NULL, 10, 1543.715, 1197.045, NULL, '2023-06-24 12:03:35', 57, 322),
(3891, 'PO-2BojqWYxs5866', '{\"en\":\"Yu Tang\",\"ko\":\"상점\",\"vi\":\"Yu Tang\"}', NULL, NULL, 10, 1423.5853271114397, 1225.7495888005917, NULL, '2023-06-24 12:03:35', 57, 304),
(3892, 'PO-5R4kul_qi7371', '{\"en\":\"Marukame Udon\",\"ko\":\"상점\",\"vi\":\"Marukame Udon\"}', NULL, NULL, 10, 1516.3841776011827, 1521.715158935502, NULL, '2023-06-24 12:03:35', 57, 300),
(3893, 'PO-Y6XTn8_q49026', '{\"en\":\"Crown Space\",\"ko\":\"상점\",\"vi\":\"Crown Space\"}', NULL, NULL, 10, 1668.44, 1129.55, NULL, '2023-06-24 12:03:35', 57, 322),
(3894, 'PO-jgBF0h39d0819', '{\"en\":\"Rookie\",\"ko\":\"상점\",\"vi\":\"Rookie\"}', NULL, NULL, 10, 1744.58, 1129.3413149889864, NULL, '2023-06-24 12:03:35', 57, 322),
(3895, 'PO-SrpC25HyN2362', '{\"en\":\"Ann House\",\"ko\":\"상점\",\"vi\":\"Ann House\"}', NULL, NULL, 10, 1863.841065422288, 1158.690158935502, NULL, '2023-06-24 12:03:35', 57, 322),
(3896, 'PO-Q2i9EOV734058', '{\"en\":\"Photo Time\",\"ko\":\"상점\",\"vi\":\"Photo Time\"}', NULL, NULL, 10, 1901.265, 1071.04, NULL, '2023-06-24 12:03:35', 57, 322),
(3897, 'PO-P_iteNWH85650', '{\"en\":\"Ushimania\",\"ko\":\"상점\",\"vi\":\"Ushimania\"}', NULL, NULL, 10, 1790.473196266864, 1459.5261495102568, NULL, '2023-06-24 12:03:35', 57, 300),
(3898, 'PO-HN9ceYkAv7330', '{\"en\":\"Gap Kids\",\"ko\":\"상점\",\"vi\":\"Gap Kids\"}', NULL, NULL, 10, 2036.015, 1087.205, NULL, '2023-06-24 12:03:35', 57, 322),
(3899, 'PO-JDe3omlfh9210', '{\"en\":\"Cath Kidston\",\"ko\":\"상점\",\"vi\":\"Cath Kidson\"}', NULL, NULL, 10, 2068.1, 1225.0299999999995, NULL, '2023-06-24 12:03:35', 57, 322),
(3900, 'PO-Pdhmg8aWo1394', '{\"en\":\"CoCo Ichibanya\",\"ko\":\"상점\",\"vi\":\"CoCo Ichibanya\"}', NULL, NULL, 10, 2038.787130844576, 1427.1608972463507, NULL, '2023-06-24 12:03:35', 57, 300),
(3901, 'PO-WLYRhht6I5186', '{\"en\":\"Albetta\",\"ko\":\"상점\",\"vi\":\"Albetta\"}', NULL, NULL, 10, 1854.68, 635.4449999999999, NULL, '2023-06-24 12:03:35', 57, 322),
(3902, 'PO-7T_9l-eG76938', '{\"en\":\"Carter\'s\",\"ko\":\"상점\",\"vi\":\"Cater\'s\"}', NULL, NULL, 10, 1964.6380699411588, 636.3678110002925, NULL, '2023-06-24 12:03:35', 57, 322),
(3903, 'PO-zLdt8JGPE8338', '{\"en\":\"Maman bebe\",\"ko\":\"상점\",\"vi\":\"Maman bebe\"}', NULL, NULL, 10, 2099.5569300588404, 632.3636919417442, NULL, '2023-06-24 12:03:35', 57, 322),
(3904, 'PO-inQwvKV5p9699', '{\"en\":\"Sadhu\",\"ko\":\"상점\",\"vi\":\"Sadhu\"}', NULL, NULL, 10, 2317.865, 554.744028293619, NULL, '2023-06-24 12:03:35', 57, 303),
(3905, 'PO-DJZ9UvQmA1186', '{\"en\":\"Central Home\",\"ko\":\"상점\",\"vi\":\"Central Home\"}', NULL, NULL, 10, 2937.3961157352437, 640.4694804110878, NULL, '2023-06-24 12:03:35', 57, 324),
(3906, 'PO-fUES_A_Gn5130', '{\"en\":\"Sa Maison\",\"ko\":\"상점\",\"vi\":\"Sa Maison\"}', NULL, NULL, 10, 2586.23, 1066.085, NULL, '2023-06-24 12:03:35', 57, 324),
(3907, 'PO-ApKHXCtno6682', '{\"en\":\"ROSADA\",\"ko\":\"상점\",\"vi\":\"ROSADA\"}', NULL, NULL, 10, 2560.002140659418, 1164.14, NULL, '2023-06-24 12:03:35', 57, 324),
(3908, 'PO-onAuf-hfJ7970', '{\"en\":\"Fissler\",\"ko\":\"상점\",\"vi\":\"Fissler\"}', NULL, NULL, 10, 2555.63, 1269.285, NULL, '2023-06-24 12:03:35', 57, 324),
(3909, 'PO-BuyP5mEzE9642', '{\"en\":\"SMEG/ Le Creuset\",\"ko\":\"상점\",\"vi\":\"SMEG/ Le Creuset\"}', NULL, NULL, 10, 2586.2250000000004, 1404.5130581098565, NULL, '2023-06-24 12:03:35', 57, 324),
(3910, 'PO-903TbNRUc1450', '{\"en\":\"Watch\",\"ko\":\"상점\",\"vi\":\"Watch\"}', NULL, NULL, 10, 2587.2739143736235, 1473.1025993846367, NULL, '2023-06-24 12:03:35', 57, 324),
(3911, 'PO-DZCvkGqzv2986', '{\"en\":\"Akemi Uchi\",\"ko\":\"상점\",\"vi\":\"Akemi Uchi\"}', NULL, NULL, 10, 2763.7779312837683, 1129.9113815539154, NULL, '2023-06-24 12:03:35', 57, 324),
(3912, 'PO-6oIbaorjJ4482', '{\"en\":\"Scatter Box\",\"ko\":\"상점\",\"vi\":\"Scatter Box\"}', NULL, NULL, 10, 2863.5664656418844, 1130.7802594931893, NULL, '2023-06-24 12:03:35', 57, 324),
(3913, 'PO-ySgVrFGsD6210', '{\"en\":\"Total Art\",\"ko\":\"상점\",\"vi\":\"Total Art\"}', NULL, NULL, 10, 2962.213534358116, 1131.1306030743474, NULL, '2023-06-24 12:03:35', 57, 324),
(3914, 'PO-pX9LWJr1C8178', '{\"en\":\"Tefal\",\"ko\":\"상점\",\"vi\":\"Tefal\"}', NULL, NULL, 10, 2819.531250883647, 1464.64477063739, NULL, '2023-06-24 12:03:35', 57, 324),
(3915, 'PO-zUgbhipAL0346', '{\"en\":\"LUG.vn\",\"ko\":\"상점\",\"vi\":\"LUG.vn\"}', NULL, NULL, 10, 2971.94, 1499.38, NULL, '2023-06-24 12:03:35', 57, 319),
(3916, 'PO-Kgd2IuPTA2834', '{\"en\":\"Kitchen Koncept\",\"ko\":\"상점\",\"vi\":\"Kitchen Koncept\"}', NULL, NULL, 10, 3097.9400000000005, 1161.1224006153634, NULL, '2023-06-24 12:03:35', 57, 324),
(3917, 'PO-LD1U8GFcr4594', '{\"en\":\"MANWAH\",\"ko\":\"상점\",\"vi\":\"MANWHA\"}', NULL, NULL, 10, 3128.5436544176773, 1448.723776791022, NULL, '2023-06-24 12:03:35', 57, 301),
(3918, 'PO-YBxqTC6tt6290', '{\"en\":\"JYSK\",\"ko\":\"상점\",\"vi\":\"JYSK\"}', NULL, NULL, 10, 3581.02, 1179.095, NULL, '2023-06-24 12:03:35', 57, 324),
(3919, 'PO-1skam_Qx-8066', '{\"en\":\"Lock&Lock\",\"ko\":\"상점\",\"vi\":\"Lock&Lock\"}', NULL, NULL, 10, 3550.3443596377747, 1444.6621798188876, NULL, '2023-06-24 12:03:35', 57, 324),
(3920, 'PO-heV6Is8Ak9922', '{\"en\":\"Adidas/ Ping Golf\",\"ko\":\"상점\",\"vi\":\"Addias/ Ping Golf\"}', NULL, NULL, 10, 3492.9399547218627, 1598.2873932729626, NULL, '2023-06-24 12:03:35', 57, 321),
(3921, 'PO-zbmqn-IkH1610', '{\"en\":\"Hazzys Golf\",\"ko\":\"상점\",\"vi\":\"Hazzys Golf\"}', NULL, NULL, 10, 3482.885, 1704.135, NULL, '2023-06-24 12:03:35', 57, 321),
(3922, 'PO-5RVnYafeC5514', '{\"en\":\"TAT Golf\",\"ko\":\"상점\",\"vi\":\"TAT Golf\"}', NULL, NULL, 10, 3469.332669532197, 1899.657343821724, NULL, '2023-06-24 12:03:35', 57, 321),
(3923, 'PO-eKbtE3x-t7338', '{\"en\":\"Taylor made\",\"ko\":\"상점\",\"vi\":\"Taylor made\"}', NULL, NULL, 10, 3281.03, 1885.3750907649292, NULL, '2023-06-24 12:03:35', 57, 321),
(3924, 'PO-3MCui0Oww8922', '{\"en\":\"FairLiar\",\"ko\":\"상점\",\"vi\":\"FairLiar\"}', NULL, NULL, 10, 3182.285, 1887.2669300588404, NULL, '2023-06-24 12:03:35', 57, 321),
(3925, 'PO-h8ieX_VQ-0546', '{\"en\":\"Descente Golf\",\"ko\":\"상점\",\"vi\":\"Descente Golf\"}', NULL, NULL, 10, 2874.085, 1854.4073705295664, NULL, '2023-06-24 12:03:35', 57, 321),
(3926, 'PO-ZVLZI4m8R1994', '{\"en\":\"Boss Golf\",\"ko\":\"상점\",\"vi\":\"Boss Golf\"}', NULL, NULL, 10, 3063.2200000000003, 1886.8189508826108, NULL, '2023-06-24 12:03:35', 57, 321),
(3927, 'PO-KznSdInzR3306', '{\"en\":\"Giovanni\",\"ko\":\"상점\",\"vi\":\"Giovanni\"}', NULL, NULL, 10, 2706.735, 1813.89, NULL, '2023-06-24 12:03:35', 57, 317),
(3928, 'PO-KhGXngmm35146', '{\"en\":\"Hokkaido Sachi\",\"ko\":\"상점\",\"vi\":\"Hokkaido Sachi\"}', NULL, NULL, 10, 2412.559786545925, 1810.343887451488, NULL, '2023-06-24 12:03:35', 57, 300),
(3929, 'PO-i3oR5LAwl8867', '{\"en\":\"La milana\",\"ko\":\"상점\",\"vi\":\"La milana\"}', NULL, NULL, 10, 1113.645, 1835.595, NULL, '2023-06-24 12:03:35', 57, 305),
(3930, 'PO-HYtXH2rzm0482', '{\"en\":\"Ding Tea\",\"ko\":\"상점\",\"vi\":\"Ding Tea\"}', NULL, NULL, 10, 1113.645, 1953.215, NULL, '2023-06-24 12:03:35', 57, 304),
(3931, 'PO-IANyTAFAJ1898', '{\"en\":\"Chops\",\"ko\":\"상점\",\"vi\":\"Chops\"}', NULL, NULL, 10, 1259.4299999999998, 1825.255, NULL, '2023-06-24 12:03:35', 57, 302),
(3932, 'PO-hSjpvRbkg3466', '{\"en\":\"Salad\",\"ko\":\"상점\",\"vi\":\"Salad\"}', NULL, NULL, 10, 1250.52, 1907.245, NULL, '2023-06-24 12:03:35', 57, 302),
(3933, 'PO-SBLzQSS6U4970', '{\"en\":\"Hanoi Taco Bar\",\"ko\":\"상점\",\"vi\":\"Hanoi Taco Bar\"}', NULL, NULL, 10, 1363.8860856263764, 1845.1893730988431, NULL, '2023-06-24 12:03:35', 57, 302),
(3934, 'PO-AfeObw39u6850', '{\"en\":\"Saint Hr\",\"ko\":\"상점\",\"vi\":\"Saint Hr\"}', NULL, NULL, 10, 1356.025, 1907.245, NULL, '2023-06-24 12:03:35', 57, 305),
(3935, 'PO-QkGZQejaM8801', '{\"en\":\"Café giang\",\"ko\":\"상점\",\"vi\":\"Café Giảng\"}', NULL, NULL, 10, 1476.1660856263768, 1863.6706574944933, NULL, '2023-06-24 12:03:35', 57, 304),
(3936, 'PO-R96Czo9ql0681', '{\"en\":\"Hey Pelo\",\"ko\":\"상점\",\"vi\":\"Hey Pelo\"}', NULL, NULL, 10, 1588.4199999999998, 1823.1563149889869, NULL, '2023-06-24 12:03:35', 57, 302),
(3937, 'PO-3XPyJ22Sy3218', '{\"en\":\"NYC Pizza\",\"ko\":\"상점\",\"vi\":\"NYC Pizza\"}', NULL, NULL, 10, 1588.42, 1871.41, NULL, '2023-06-24 12:03:35', 57, 302),
(3938, 'PO-TKnE9brJW5034', '{\"en\":\"Chen lin food\",\"ko\":\"상점\",\"vi\":\"Chen lin food\"}', NULL, NULL, 10, 1775.1739143736231, 1787.80022936261, NULL, '2023-06-24 12:03:35', 57, 301),
(3939, 'PO-J7xdFx1i16850', '{\"en\":\"La Viet Coffee\",\"ko\":\"상점\",\"vi\":\"Là Việt Coffee\"}', NULL, NULL, 10, 1261.44, 2026.63, NULL, '2023-06-24 12:03:35', 57, 304),
(3940, 'PO-tYIcEQBuh9162', '{\"en\":\"Su un dang\",\"ko\":\"상점\",\"vi\":\"Su un dang\"}', NULL, NULL, 10, 1749.89, 1856.45, NULL, '2023-06-24 12:03:35', 57, 299),
(3941, 'PO-r87oXmfYU3130', '{\"en\":\"Yukichi\",\"ko\":\"상점\",\"vi\":\"Yukichi\"}', NULL, NULL, 10, 1927.75, 1734.2163925337277, NULL, '2023-06-24 12:03:35', 57, 300),
(3942, 'PO-Eycy_xPXI4802', '{\"en\":\"Maazi\",\"ko\":\"상점\",\"vi\":\"Mazzi\"}', NULL, NULL, 10, 1927.75, 1807.975, NULL, '2023-06-24 12:03:35', 57, 303),
(3943, 'PO-kVTPDhMxP7178', '{\"en\":\"Som Thai\",\"ko\":\"상점\",\"vi\":\"Som Thai\"}', NULL, NULL, 10, 2100.262145996095, 1783.236328125, NULL, '2023-06-24 12:03:35', 57, 303),
(3944, 'PO-u51vNllny1714', '{\"en\":\"Pho thin\",\"ko\":\"상점\",\"vi\":\"Phở Thìn\"}', NULL, NULL, 10, 1973.37, 1869.7915607096647, NULL, '2023-06-24 12:03:35', 57, 303),
(3945, 'PO-LDZ-m0sdP4018', '{\"en\":\"Clever\",\"ko\":\"상점\",\"vi\":\"Clever\"}', NULL, NULL, 10, 1595.2301681759377, 826.7850267078431, NULL, '2023-06-24 12:03:35', 57, 322),
(3946, 'PO-gIUd8wBct2834', '{\"en\":\"Alpha\",\"ko\":\"상점\",\"vi\":\"Alpha\"}', NULL, NULL, 10, 2199.885, 693.035, NULL, '2023-06-24 12:03:35', 57, 322),
(3947, 'PO-cPgIDud896518', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 942.97, 1705.19, NULL, '2023-06-24 12:03:35', 57, 329),
(3948, 'PO-IUX2epu-L8294', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.97, 1705.19, NULL, '2023-06-24 12:03:35', 57, 329),
(3949, 'PO-iRXvjzAUV9703', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 942.97, 1855, NULL, '2023-06-24 12:03:35', 57, 329),
(3950, 'PO-QRcfrYOL51326', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.97, 1800, NULL, '2023-06-24 12:03:35', 57, 329),
(3951, 'PO-eiUsr2r543510', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 997.97, 1855, NULL, '2023-06-24 12:03:35', 57, 329),
(3952, 'PO-QPcKZihRB6934', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1275.1289166691577, 1462.2101296763735, NULL, '2023-06-24 12:03:35', 57, 328),
(3953, 'PO-9o2Rui9sF9502', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1757.2943821463668, 1649.47223679604, NULL, '2023-06-24 12:03:35', 57, 328),
(3954, 'PO-xysbzFIDb3094', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1653.4999624832917, 965.3748018110408, NULL, '2023-06-24 12:03:35', 57, 328),
(3955, 'PO-T_yHmx1Ao5950', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2282.447531161481, 1044.7811073334194, NULL, '2023-06-24 12:03:35', 57, 328),
(3956, 'PO-9SBcUM8No7870', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2188.9157363654936, 1225.3824647647573, NULL, '2023-06-24 12:03:35', 57, 328),
(3957, 'PO-2O62ou4rk9918', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2422.286065422288, 1365.7, NULL, '2023-06-24 12:03:35', 57, 329),
(3958, 'PO-R8DSwshYT1574', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2420.9, 1420.7, NULL, '2023-06-24 12:03:35', 57, 329),
(3959, 'PO-j35oLyfXs4710', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2974.346929989585, 976.0078024098966, NULL, '2023-06-24 12:03:35', 57, 328),
(3960, 'PO-yo87F4ccB6462', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3515, 955.8, NULL, '2023-06-24 12:03:35', 57, 329),
(3961, 'PO-gRQW2plug0326', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3693.84, 836.61, NULL, '2023-06-24 12:03:35', 57, 329),
(3962, 'PO-m2PTdlSl12542', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3693.84, 891.61, NULL, '2023-06-24 12:03:35', 57, 329),
(3963, 'PO-MTQ13Yb964894', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3570, 955.8, NULL, '2023-06-24 12:03:35', 57, 329),
(3964, 'PO-9J-o5wRP68190', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2594.442743403615, 1612.6998604669948, NULL, '2023-06-24 12:03:35', 57, 328),
(3965, 'PO-n7-11fPYL0126', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3361.5861841529745, 1453.7838122610967, NULL, '2023-06-24 12:03:35', 57, 328),
(3966, 'PO-im0o139BJ3686', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3624.07, 1919.27, NULL, '2023-06-24 12:03:35', 57, 329),
(3967, 'PO-4p8On1mkD6270', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3624.07, 1864.27, NULL, '2023-06-24 12:03:35', 57, 329),
(3968, 'PO-qAQBCLAl_8438', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3624.07, 1809.27, NULL, '2023-06-24 12:03:35', 57, 329),
(3969, 'PO-KuldPyOwC7070', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3630.84, 1725.99, NULL, '2023-06-24 12:03:35', 57, 311),
(3970, 'PO-RHegcX9zQ3758', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3693.84, 781.61, NULL, '2023-06-24 12:03:35', 57, 311),
(3971, 'PO-PRaolo5yf3431', '{\"en\":\"Medical room\",\"ko\":\"상점\",\"vi\":\"Phòng y tế\"}', NULL, NULL, 10, 3542.5, 896.2049999999999, NULL, '2023-06-24 12:03:35', 57, 314),
(3972, 'PO-u7LgyFQMG8030', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 3515, 836.61, NULL, '2023-06-24 12:03:35', 57, 309),
(3973, 'PO-1anlEw3y89854', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 3515, 781.61, NULL, '2023-06-24 12:03:35', 57, 309),
(3974, 'PO-baNI3K64U3324', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 1819.8, 1288.64, NULL, '2023-06-24 12:03:35', 57, 309),
(3975, 'PO-i_yNYf3YJ5492', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 1819.8, 1343.64, NULL, '2023-06-24 12:03:35', 57, 309),
(3976, 'PO-O7v8bfU0l1156', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 2830.41, 1289.46, NULL, '2023-06-24 12:03:35', 57, 309),
(3977, 'PO-tDq8LH39N3493', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 2830.41, 1344.46, NULL, '2023-06-24 12:03:35', 57, 309),
(3978, 'PO-_uNXuaxmz9438', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 1913.59, 1288.64, NULL, '2023-06-24 12:03:35', 57, 312),
(3979, 'PO-c2mBBAXEo2429', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 1913.59, 1343.64, NULL, '2023-06-24 12:03:35', 57, 313),
(3980, 'PO-J7oVqX-wM7237', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 2729.44, 1344.46, NULL, '2023-06-24 12:03:35', 57, 313),
(3981, 'PO-8bkZMqVqi0725', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 2729.44, 1289.29, NULL, '2023-06-24 12:03:35', 57, 312),
(3982, 'PO-Fvlsmq3dt8242', '{\"en\":\"Gourmet Foodhall\",\"ko\":\"상점\",\"vi\":\"Khu ẩm thực Gourmet\"}', NULL, NULL, 10, 1459.5656431620368, 2007.703159221058, NULL, '2023-06-24 12:03:35', 57, 306),
(3983, 'PO-bRxk7DqAe5763', '{\"en\":\"Marks & Spencer\",\"ko\":\"상점\",\"vi\":\"Marks & Spencer\"}', NULL, NULL, 10, 1048.065, 1076.39, NULL, '2023-06-24 12:03:35', 58, 318),
(3984, 'PO-Om1y823_E7153', '{\"en\":\"Pull&Bear\",\"ko\":\"상점\",\"vi\":\"Pull&Bear\"}', NULL, NULL, 10, 1587.78122435779, 800.0588504897431, NULL, '2023-06-24 12:03:35', 58, 318),
(3985, 'PO-XkRJKBKLR8905', '{\"en\":\"Giordano\",\"ko\":\"상점\",\"vi\":\"Giordano\"}', NULL, NULL, 10, 1116.12467288856, 1355.358607466272, NULL, '2023-06-24 12:03:35', 58, 318),
(3986, 'PO-sm1XLRhzC2857', '{\"en\":\"MVG Lounge\",\"ko\":\"상점\",\"vi\":\"Dịch vụ CSKH\\n(VIP)\"}', NULL, NULL, 10, 1052.24, 1553.78, NULL, '2023-06-24 12:03:35', 58, 308),
(3987, 'PO-0WliSXd8F4529', '{\"en\":\"Ked\'s\",\"ko\":\"상점\",\"vi\":\"Ked\'s\"}', NULL, NULL, 10, 1207.323934577712, 1424.625, NULL, '2023-06-24 12:03:35', 58, 321),
(3988, 'PO-VNdYbqQta6041', '{\"en\":\"New Balance\",\"ko\":\"상점\",\"vi\":\"New Balance\"}', NULL, NULL, 10, 1192.4207383108485, 1523.71, NULL, '2023-06-24 12:03:35', 58, 321),
(3989, 'PO-T8QmJJRvx7633', '{\"en\":\"Converse\",\"ko\":\"상점\",\"vi\":\"Converse\"}', NULL, NULL, 10, 1203.48967288856, 1644.72, NULL, '2023-06-24 12:03:35', 58, 321),
(3990, 'PO-g7wektNZS9537', '{\"en\":\"Levi\'s\",\"ko\":\"상점\",\"vi\":\"Levi\'s\"}', NULL, NULL, 10, 1906.005, 786.645, NULL, '2023-06-24 12:03:35', 58, 318),
(3991, 'PO-3fAi7lawH2945', '{\"en\":\"MLB\",\"ko\":\"상점\",\"vi\":\"MLB\"}', NULL, NULL, 10, 2054.46, 706.2049999999999, NULL, '2023-06-24 12:03:35', 58, 318),
(3992, 'PO--FLpo4nQK4553', '{\"en\":\"New Drops\",\"ko\":\"상점\",\"vi\":\"New Drops\"}', NULL, NULL, 10, 2186.5199999999995, 706.2049999999999, NULL, '2023-06-24 12:03:35', 58, 318),
(3993, 'PO-m_rkU14b46009', '{\"en\":\"Guess\",\"ko\":\"상점\",\"vi\":\"Guess\"}', NULL, NULL, 10, 2450.28, 706.2049999999999, NULL, '2023-06-24 12:03:35', 58, 318),
(3994, 'PO-uuyP9nFGU8505', '{\"en\":\"The North Face\",\"ko\":\"상점\",\"vi\":\"The North Face\"}', NULL, NULL, 10, 2578.9939345777125, 611.9525512844193, NULL, '2023-06-24 12:03:35', 58, 321),
(3995, 'PO-VEyWU38GH1129', '{\"en\":\"Timber land\",\"ko\":\"상점\",\"vi\":\"Timber land\"}', NULL, NULL, 10, 2541.19, 744.4549999999999, NULL, '2023-06-24 12:03:35', 58, 321),
(3996, 'PO-fWqHsaKm23209', '{\"en\":\"Runam\",\"ko\":\"상점\",\"vi\":\"Runam\"}', NULL, NULL, 10, 2327.25, 924.17, NULL, '2023-06-24 12:03:35', 58, 304),
(3997, 'PO-EgAFOKqh76473', '{\"en\":\"Columbia\",\"ko\":\"상점\",\"vi\":\"Columbia\"}', NULL, NULL, 10, 2742.805, 670.8116447976338, NULL, '2023-06-24 12:03:35', 58, 321),
(3998, 'PO-ekduT7aFe8009', '{\"en\":\"Fila\",\"ko\":\"상점\",\"vi\":\"Fila\"}', NULL, NULL, 10, 2838.795, 800.0899999999999, NULL, '2023-06-24 12:03:35', 58, 321),
(3999, 'PO-RJa1biMe-9377', '{\"en\":\"Superior & Sports\",\"ko\":\"상점\",\"vi\":\"SuperSports\"}', NULL, NULL, 10, 3197.6745047126237, 800.774420624654, NULL, '2023-06-24 12:03:35', 58, 321),
(4000, 'PO-AYHXp8qlQ1345', '{\"en\":\"Crocs\",\"ko\":\"상점\",\"vi\":\"Crocs\"}', NULL, NULL, 10, 3349.9024579560155, 963.608934577712, NULL, '2023-06-24 12:03:35', 58, 321),
(4001, 'PO-PJ54uwNpD4441', '{\"en\":\"Beauty Box\",\"ko\":\"상점\",\"vi\":\"Beauty Box\"}', NULL, NULL, 10, 3508.6221308445765, 1093.931065422288, NULL, '2023-06-24 12:03:35', 58, 320),
(4002, 'PO-yePTqzE0n6025', '{\"en\":\"Guardian\",\"ko\":\"상점\",\"vi\":\"Guardian\"}', NULL, NULL, 10, 3521.1717251350738, 1184.8879312837685, NULL, '2023-06-24 12:03:35', 58, 320),
(4003, 'PO-K6v5LoG_v7697', '{\"en\":\"Gigi\",\"ko\":\"상점\",\"vi\":\"Gigi\"}', NULL, NULL, 10, 3520.11, 1269.935, NULL, '2023-06-24 12:03:35', 58, 316),
(4004, 'PO-Ic0Aeg8AV9818', '{\"en\":\"Lovisa\",\"ko\":\"상점\",\"vi\":\"Lovisa\"}', NULL, NULL, 10, 3464.814656418842, 1366.3893969256528, NULL, '2023-06-24 12:03:35', 58, 319),
(4005, 'PO-WfOQmCB0z1521', '{\"en\":\"Kelly Bui\",\"ko\":\"상점\",\"vi\":\"Kelly Bui\"}', NULL, NULL, 10, 3485.5531907769573, 1474.0293969256527, NULL, '2023-06-24 12:03:35', 58, 316),
(4006, 'PO-F-GqoQQKc3169', '{\"en\":\"Sixdo\",\"ko\":\"상점\",\"vi\":\"Sixdo\"}', NULL, NULL, 10, 3423.8574963853584, 1604.8385343581158, NULL, '2023-06-24 12:03:35', 58, 316),
(4007, 'PO-XTEmTJLp95066', '{\"en\":\"Lush\",\"ko\":\"상점\",\"vi\":\"Lush\"}', NULL, NULL, 10, 2563.005, 1107.48, NULL, '2023-06-24 12:03:35', 58, 320),
(4008, 'PO-QWVG2kVsO6457', '{\"en\":\"Mujosh\",\"ko\":\"상점\",\"vi\":\"Mujosh\"}', NULL, NULL, 10, 2538.005, 1223.9633237035966, NULL, '2023-06-24 12:03:35', 58, 319),
(4009, 'PO-xrDgGlMQ07849', '{\"en\":\"Marhen.J\",\"ko\":\"상점\",\"vi\":\"Marhen.J\"}', NULL, NULL, 10, 2538.005, 1317.3850000000002, NULL, '2023-06-24 12:03:35', 58, 319),
(4010, 'PO-FbR-S_wvt9113', '{\"en\":\"Pedro\",\"ko\":\"상점\",\"vi\":\"Pedro\"}', NULL, NULL, 10, 2564.251930058841, 1434.877279764637, NULL, '2023-06-24 12:03:35', 58, 319),
(4011, 'PO-TwUHpvr0o0553', '{\"en\":\"The Body \\nShop\",\"ko\":\"상점\",\"vi\":\"The Body\\nShop\"}', NULL, NULL, 10, 2718.75, 1125.955, NULL, '2023-06-24 12:03:35', 58, 320),
(4012, 'PO-mF8FvFYWs1970', '{\"en\":\"Innisfree\",\"ko\":\"상점\",\"vi\":\"Innisfree\"}', NULL, NULL, 10, 2828.141075988526, 1143.8702723492197, NULL, '2023-06-24 12:03:35', 58, 320),
(4013, 'PO-8zPPYQzmX3217', '{\"en\":\"Harnn\",\"ko\":\"상점\",\"vi\":\"Harnn\"}', NULL, NULL, 10, 2926.54, 1144.527733698147, NULL, '2023-06-24 12:03:35', 58, 320),
(4014, 'PO-yHcD86N7i4665', '{\"en\":\"Charles & Keith\",\"ko\":\"상점\",\"vi\":\"Charles & Keith\"}', NULL, NULL, 10, 2765.0157901765224, 1457.6525335270746, NULL, '2023-06-24 12:03:35', 58, 319),
(4015, 'PO-xL3mYOHpp6113', '{\"en\":\"Lyn\",\"ko\":\"상점\",\"vi\":\"Lyn\"}', NULL, NULL, 10, 2906.32, 1457.40797917623, NULL, '2023-06-24 12:03:35', 58, 319),
(4016, 'PO-oNQBXQapP9481', '{\"en\":\"Parfois\",\"ko\":\"상점\",\"vi\":\"Parfois\"}', NULL, NULL, 10, 3153.097004049721, 1257.0982279655775, NULL, '2023-06-24 12:03:35', 58, 319),
(4017, 'PO-op4DJOGWA1241', '{\"en\":\"Estelle\",\"ko\":\"상점\",\"vi\":\"Estelle\"}', NULL, NULL, 10, 3044.415, 1169.3823839923507, NULL, '2023-06-24 12:03:35', 58, 319),
(4018, 'PO-fu_DjSs7S4762', '{\"en\":\"Acme De La Vie\",\"ko\":\"상점\",\"vi\":\"Acme De La Vie\"}', NULL, NULL, 10, 2440.895, 1783.02, NULL, '2023-06-24 12:03:35', 58, 318),
(4019, 'PO-geOQd-L4q6249', '{\"en\":\"Nerdy\",\"ko\":\"상점\",\"vi\":\"Nerdy\"}', NULL, NULL, 10, 2534.695, 1783.02, NULL, '2023-06-24 12:03:35', 58, 318),
(4020, 'PO-xHhLQROzN8441', '{\"en\":\"Ceci\",\"ko\":\"상점\",\"vi\":\"Ceci\"}', NULL, NULL, 10, 2627.13, 1748.27, NULL, '2023-06-24 12:03:35', 58, 319),
(4021, 'PO-dD71uOjOA0001', '{\"en\":\"Muji\",\"ko\":\"상점\",\"vi\":\"Muji\"}', NULL, NULL, 10, 3071.695778479568, 1899.7931633274272, NULL, '2023-06-24 12:03:35', 58, 318),
(4022, 'PO-kgJED-BOE3425', '{\"en\":\"Foot Locker\",\"ko\":\"상점\",\"vi\":\"Foot Locker\"}', NULL, NULL, 10, 1342.9779312837682, 1902.8645651015904, NULL, '2023-06-24 12:03:35', 58, 321),
(4023, 'PO-td7fwWwlj4817', '{\"en\":\"Skechers\",\"ko\":\"상점\",\"vi\":\"Skechers\"}', NULL, NULL, 10, 1639.113534358116, 1898.696122060726, NULL, '2023-06-24 12:03:35', 58, 321),
(4024, 'PO-klmZ1VeWm7345', '{\"en\":\"Adidas\",\"ko\":\"상점\",\"vi\":\"Adidas\"}', NULL, NULL, 10, 1853.74, 1835.2125877026103, NULL, '2023-06-24 12:03:35', 58, 321),
(4025, 'PO-MbOk_lQKY8761', '{\"en\":\"Puma\",\"ko\":\"상점\",\"vi\":\"Puma\"}', NULL, NULL, 10, 2103.8050000000003, 1783.025, NULL, '2023-06-24 12:03:35', 58, 321),
(4026, 'PO-Yo9THhQDp0793', '{\"en\":\"Mango\",\"ko\":\"상점\",\"vi\":\"Mango\"}', NULL, NULL, 10, 1566.811925465839, 1520.5939440993798, NULL, '2023-06-24 12:03:35', 58, 318),
(4027, 'PO-wkqc4NOAI2945', '{\"en\":\"Vans\",\"ko\":\"상점\",\"vi\":\"Vans\"}', NULL, NULL, 10, 1708.35, 1490.065, NULL, '2023-06-24 12:03:35', 58, 321),
(4028, 'PO-op9UU5qP85041', '{\"en\":\"Sneaker Buzz\",\"ko\":\"상점\",\"vi\":\"Sneaker Buzz\"}', NULL, NULL, 10, 1796.225, 1478.625213454075, NULL, '2023-06-24 12:03:35', 58, 321),
(4029, 'PO-Jx9jr4l4E7001', '{\"en\":\"New Era\",\"ko\":\"상점\",\"vi\":\"New Era\"}', NULL, NULL, 10, 1896.516392533728, 1449.70967288856, NULL, '2023-06-24 12:03:35', 58, 318),
(4030, 'PO-YW7ohkhE90193', '{\"en\":\"Clarks\",\"ko\":\"상점\",\"vi\":\"Clarks\"}', NULL, NULL, 10, 1482.9302594931892, 1239.7181907769575, NULL, '2023-06-24 12:03:35', 58, 319),
(4031, 'PO-AQqomxr0R1666', '{\"en\":\"Camper\",\"ko\":\"상점\",\"vi\":\"Camper\"}', NULL, NULL, 10, 1594.0099999999998, 1222.2223282094208, NULL, '2023-06-24 12:03:35', 58, 319),
(4032, 'PO-Wqk_DmcVk3402', '{\"en\":\"Birken stock\",\"ko\":\"상점\",\"vi\":\"Birken stock\"}', NULL, NULL, 10, 1708.35, 1155.455, NULL, '2023-06-24 12:03:35', 58, 319),
(4033, 'PO-WOQiSbqre5017', '{\"en\":\"Geox\",\"ko\":\"상점\",\"vi\":\"Geox\"}', NULL, NULL, 10, 1781.255, 1155.1002594931892, NULL, '2023-06-24 12:03:35', 58, 319),
(4034, 'PO-wesq7UrIY6433', '{\"en\":\"Rock port\",\"ko\":\"상점\",\"vi\":\"Rock port\"}', NULL, NULL, 10, 1854.326465641884, 1154.0105189863789, NULL, '2023-06-24 12:03:35', 58, 319),
(4035, 'PO-STCnxZ4xR7978', '{\"en\":\"Ecco\",\"ko\":\"상점\",\"vi\":\"Ecco\"}', NULL, NULL, 10, 1926.816465641884, 1153.5107784795678, NULL, '2023-06-24 12:03:35', 58, 319),
(4036, 'PO-ldnGi4zMd9745', '{\"en\":\"Calvin Klein\",\"ko\":\"상점\",\"vi\":\"Calvin Klein\"}', NULL, NULL, 10, 2058.505, 1122.335, NULL, '2023-06-24 12:03:35', 58, 318),
(4037, 'PO-w-RBxKhYT1505', '{\"en\":\"FLASQ\",\"ko\":\"상점\",\"vi\":\"FLASQ\"}', NULL, NULL, 10, 2083.505, 1303.69, NULL, '2023-06-24 12:03:35', 58, 318),
(4038, 'PO-sJ9LoBz1j3345', '{\"en\":\"Cole Haan\",\"ko\":\"상점\",\"vi\":\"Cole Haan\"}', NULL, NULL, 10, 2058.5, 1446.1846728885605, NULL, '2023-06-24 12:03:35', 58, 319),
(4039, 'PO-9nPEWtXSX2438', '{\"en\":\"Service Lounge\",\"ko\":\"NO NAME\",\"vi\":\"Dịch vụ CSKH\"}', NULL, NULL, 10, 944.74, 1578.78, NULL, '2023-06-24 12:03:35', 58, 308),
(4040, 'PO-Mta8GPOoW4765', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1024.7299999999996, 1674.7900000000004, NULL, '2023-06-24 12:03:35', 58, 329),
(4041, 'PO-EsIBLSG2-6485', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1079.7299999999996, 1674.7900000000002, NULL, '2023-06-24 12:03:35', 58, 329),
(4042, 'PO-Jev87skjG7997', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1079.7400000000002, 1778.26, NULL, '2023-06-24 12:03:35', 58, 329),
(4043, 'PO-aMsmGWuuk9517', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1079.7400000000002, 1833.26, NULL, '2023-06-24 12:03:35', 58, 329),
(4044, 'PO-3sn9m2wi41301', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1024.7400000000002, 1833.26, NULL, '2023-06-24 12:03:35', 58, 329),
(4045, 'PO-IVIC9BGEl3061', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 914.74, 1833.26, NULL, '2023-06-24 12:03:35', 58, 309),
(4046, 'PO-0fxxl8gOJ5141', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 969.74, 1833.26, NULL, '2023-06-24 12:03:35', 58, 309),
(4047, 'PO-FDB_u9pqj9069', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 3490.6, 788.63, NULL, '2023-06-24 12:03:35', 58, 309),
(4048, 'PO-ZLe1Toxma1389', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 3545.6, 788.63, NULL, '2023-06-24 12:03:35', 58, 309),
(4049, 'PO-LYEOAGQOP4788', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3545.6000000000004, 843.6299999999997, NULL, '2023-06-24 12:03:35', 58, 329),
(4050, 'PO-gADOMy-CZ6676', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3435.67, 953.63, NULL, '2023-06-24 12:03:35', 58, 329),
(4051, 'PO-1p71nDOxA8381', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3490.67, 953.63, NULL, '2023-06-24 12:03:35', 58, 329),
(4052, 'PO-08eh7ONYX0156', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3545.6000000000004, 898.6299999999997, NULL, '2023-06-24 12:03:35', 58, 329),
(4053, 'PO-nEKiH192H1493', '{\"en\":\"Repair service\",\"ko\":\"NO NAME\",\"vi\":\"Dịch vụ sửa đồ\"}', NULL, NULL, 10, 3545.67, 953.63, NULL, '2023-06-24 12:03:35', 58, 310),
(4054, 'PO-XQPSwA4Oe2212', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 2822.9, 1290.09, NULL, '2023-06-24 12:03:35', 58, 309),
(4055, 'PO-MDLflCSlV4052', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 2822.9, 1345.09, NULL, '2023-06-24 12:03:35', 58, 309),
(4056, 'PO-fjivJubAQ9564', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2394.8900000000003, 1366.1800000000003, NULL, '2023-06-24 12:03:35', 58, 329),
(4057, 'PO-jB7ZmwtKq0916', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2394.8900000000003, 1419.6276067270378, NULL, '2023-06-24 12:03:35', 58, 329),
(4058, 'PO-IV_Hh_VvA2837', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 2699.62, 1290.09, NULL, '2023-06-24 12:03:35', 58, 312),
(4059, 'PO-b8kLOtTnu2533', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 2699.62, 1345.09, NULL, '2023-06-24 12:03:35', 58, 313),
(4060, 'PO-TkDyx9iT71837', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 1935.69, 1342.7, NULL, '2023-06-24 12:03:35', 58, 313),
(4061, 'PO-_PJMsPkRV4076', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 1935.69, 1287.7, NULL, '2023-06-24 12:03:35', 58, 312),
(4062, 'PO-fgDUETZwA5252', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 1840.71, 1287.7, NULL, '2023-06-24 12:03:35', 58, 309),
(4063, 'PO-oKKYLqqiF7124', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 1840.71, 1342.7, NULL, '2023-06-24 12:03:35', 58, 309),
(4064, 'PO-0Mx_i91Aa6115', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3543.5199999999995, 1788.6899999999996, NULL, '2023-06-24 12:03:35', 58, 329),
(4065, 'PO-HDu9tEH5S7835', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3543.5199999999995, 1843.69, NULL, '2023-06-24 12:03:35', 58, 329),
(4066, 'PO-Ptp0_L2_F9819', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3543.5199999999995, 1898.69, NULL, '2023-06-24 12:03:35', 58, 329),
(4067, 'PO-zxBoRiBAO0491', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2318.7149418783674, 1109.0343254279005, NULL, '2023-06-24 12:03:35', 58, 328),
(4068, 'PO-bor2JFT2_0275', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2943.8587055151847, 986.950570153821, NULL, '2023-06-24 12:03:35', 58, 328),
(4069, 'PO-8bkkCr6M33290', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2209.6966282919448, 1237.5177385379557, NULL, '2023-06-24 12:03:35', 58, 328),
(4070, 'PO-267iZp-Hj6834', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1689.2520769632065, 985.7885399230842, NULL, '2023-06-24 12:03:35', 58, 328),
(4071, 'PO-nyIuLU6mV3859', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1340.4463072339472, 1459.3091977904485, NULL, '2023-06-24 12:03:35', 58, 328),
(4072, 'PO-iCIdrK58z6538', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1801.2891294882468, 1657.5921596763228, NULL, '2023-06-24 12:03:35', 58, 328),
(4073, 'PO-J-MTwSL-N8211', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2826.823938993788, 1630.468732454682, NULL, '2023-06-24 12:03:35', 58, 328),
(4074, 'PO-zPHi-o8L_0178', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3292.487141488872, 1452.8592117338776, NULL, '2023-06-24 12:03:35', 58, 328),
(4075, 'PO-G8J6ols4d1042', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3490.6, 701.47, NULL, '2023-06-24 12:03:35', 58, 311),
(4076, 'PO-f0VWWua5p0266', '{\"en\":\"Smoking room\",\"ko\":\"NO NAME\",\"vi\":\"Phòng hút thuốc\"}', NULL, NULL, 10, 3543.52, 1738.69, NULL, '2023-06-24 12:03:35', 58, 311),
(4077, 'PO-pGZlYAND58483', '{\"en\":\"Who\'s Fan Cafe\",\"ko\":\"상점\",\"vi\":\"Who\'s Fan Cafe\"}', NULL, NULL, 10, 3077.761903486868, 1480.2211442883356, NULL, '2023-06-24 12:03:35', 58, 304),
(4078, 'PO-av5nbwYKk1248', '{\"en\":\"Audi\",\"ko\":\"상점\",\"vi\":\"Audi\"}', NULL, NULL, 10, 736.0900000000001, 858.7750000000001, NULL, '2023-06-24 12:03:35', 59, 324),
(4079, 'PO-rwJlE9zML2964', '{\"en\":\"Massimo Dutti\",\"ko\":\"상점\",\"vi\":\"Massimo Dutti\"}', NULL, NULL, 10, 1030.1207763975162, 1066.926149068324, NULL, '2023-06-24 12:03:35', 59, 318),
(4080, 'PO-08hpn6aPI7598', '{\"en\":\"Zara\",\"ko\":\"상점\",\"vi\":\"Zara\"}', NULL, NULL, 10, 1692.9350840336135, 730.2050164413586, NULL, '2023-06-24 12:03:35', 59, 318),
(4081, 'PO-KTgnglUAO2008', '{\"en\":\"Apple\",\"ko\":\"상점\",\"vi\":\"Apple\"}', NULL, NULL, 10, 1156.2343478260873, 1413.8908385093162, NULL, '2023-06-24 12:03:35', 59, 324),
(4082, 'PO-tEOEPNr0S5528', '{\"en\":\"Information Desk\",\"ko\":\"상점\",\"vi\":\"Quầy thông tin\"}', NULL, NULL, 10, 1045.2561070515148, 1626.4649159663863, NULL, '2023-06-24 12:03:35', 59, 315),
(4083, 'PO-Mwx0mhHao9045', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 995.5100000000002, 1681.5600000000004, NULL, '2023-06-24 12:03:35', 59, 329),
(4084, 'PO-DlOST2KSz0153', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1050.5100000000002, 1681.5600000000002, NULL, '2023-06-24 12:03:35', 59, 329),
(4085, 'PO-e9YK2jC2A8094', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 995.5099999999998, 1840.03, NULL, '2023-06-24 12:03:35', 59, 329);
INSERT INTO `pois` (`id`, `map_poi_id`, `title`, `desc`, `seq_code`, `branch_id`, `coordinate_x`, `coordinate_y`, `phone`, `created_at`, `floor_id`, `category_id`) VALUES
(4086, 'PO-WHjagXBJ39443', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1050.5099999999998, 1785.03, NULL, '2023-06-24 12:03:35', 59, 329),
(4087, 'PO-ElyhRcdoq4924', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 940.51, 1840.03, NULL, '2023-06-24 12:03:35', 59, 309),
(4088, 'PO-xNsPFWfPJ6586', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 885.51, 1840.03, NULL, '2023-06-24 12:03:35', 59, 309),
(4089, 'PO-pvQn3-UXu0326', '{\"en\":\"Artisee\",\"ko\":\"상점\",\"vi\":\"Artisee\"}', NULL, NULL, 10, 881.9649999999999, 2186.6800000000003, NULL, '2023-06-24 12:03:35', 59, 304),
(4090, 'PO-bfeXARb7F1343', '{\"en\":\"El Gaucho\",\"ko\":\"상점\",\"vi\":\"El Gaucho\"}', NULL, NULL, 10, 986.7631214791272, 2066.913265925177, NULL, '2023-06-24 12:03:35', 59, 302),
(4091, 'PO-ZrteldJwV2583', '{\"en\":\"Nike Flagship\",\"ko\":\"상점\",\"vi\":\"Nike Flagship\"}', NULL, NULL, 10, 1232.8386992633252, 1978.288497038856, NULL, '2023-06-24 12:03:35', 59, 321),
(4092, 'PO-djgO6M4vS4029', '{\"en\":\"Starbucks\",\"ko\":\"상점\",\"vi\":\"Starbucks\"}', NULL, NULL, 10, 1526.04, 2012.88, NULL, '2023-06-24 12:03:35', 59, 304),
(4093, 'PO-As5LuUu-Q5154', '{\"en\":\"Brooks Brothers\",\"ko\":\"상점\",\"vi\":\"Brooks Brothers\"}', NULL, NULL, 10, 1619.7188735940908, 1841.3560575793188, NULL, '2023-06-24 12:03:35', 59, 317),
(4094, 'PO-Fv7iy13N66513', '{\"en\":\"Poke Olle\",\"ko\":\"상점\",\"vi\":\"Poke Olle\"}', NULL, NULL, 10, 1690.36, 1956.17, NULL, '2023-06-24 12:03:35', 59, 302),
(4095, 'PO-IB9bhx5TW8782', '{\"en\":\"Hanoia\",\"ko\":\"상점\",\"vi\":\"Hanoia\"}', NULL, NULL, 10, 1451.37, 1861.265, NULL, '2023-06-24 12:03:35', 59, 316),
(4096, 'PO-gfFzLqn2p2884', '{\"en\":\"Tumi\",\"ko\":\"상점\",\"vi\":\"Tumi\"}', NULL, NULL, 10, 1825.45, 1778.575, NULL, '2023-06-24 12:03:35', 59, 319),
(4097, 'PO-49a9MEjBh3956', '{\"en\":\"KOI Thé\",\"ko\":\"상점\",\"vi\":\"KOI Thé\"}', NULL, NULL, 10, 1825.45, 1911.7477816014773, NULL, '2023-06-24 12:03:35', 59, 304),
(4098, 'PO-b3aCzsHqv5028', '{\"en\":\"Seoul Gansik\",\"ko\":\"상점\",\"vi\":\"Seoul Gansik\"}', NULL, NULL, 10, 1947.35, 1912.75, NULL, '2023-06-24 12:03:35', 59, 299),
(4099, 'PO-vrN2YoLM76058', '{\"en\":\"Hoa Club\",\"ko\":\"상점\",\"vi\":\"Hoa Club\"}', NULL, NULL, 10, 2030.68, 1807.81, NULL, '2023-06-24 12:03:35', 59, 324),
(4100, 'PO-svGeLvhND7358', '{\"en\":\"Polo Ralph\\nLauren\",\"ko\":\"상점\",\"vi\":\"Polo Ralph\\nLauren\"}', NULL, NULL, 10, 1914.915, 1768.555, NULL, '2023-06-24 12:03:35', 59, 316),
(4101, 'PO-RtensPglt8456', '{\"en\":\"Diptyque\",\"ko\":\"상점\",\"vi\":\"Diptyque\"}', NULL, NULL, 10, 2030.68, 1698.4299999999998, NULL, '2023-06-24 12:03:35', 59, 320),
(4102, 'PO-IA-7KmPXp9556', '{\"en\":\"Hugo Boss\",\"ko\":\"상점\",\"vi\":\"Hugo Boss\"}', NULL, NULL, 10, 2201.2044639481505, 1748.9976910613016, NULL, '2023-06-24 12:03:35', 59, 323),
(4103, 'PO-DIS4XYHUa2491', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2134.02, 1795.53, NULL, '2023-06-24 12:03:35', 59, 328),
(4104, 'PO-7yrnzrE8M8351', '{\"en\":\"Coach\",\"ko\":\"상점\",\"vi\":\"Coach\"}', NULL, NULL, 10, 2448.14, 1735.3994027711417, NULL, '2023-06-24 12:03:35', 59, 323),
(4105, 'PO-PLuzH5-om9580', '{\"en\":\"Ka Koncept\",\"ko\":\"상점\",\"vi\":\"Ka Koncept\"}', NULL, NULL, 10, 2563.275, 1837.38, NULL, '2023-06-24 12:03:35', 59, 320),
(4106, 'PO-iLUKveMhj1150', '{\"en\":\"Kate Spade\",\"ko\":\"상점\",\"vi\":\"Kate Spade\"}', NULL, NULL, 10, 2576.46, 1700.49, NULL, '2023-06-24 12:03:35', 59, 319),
(4107, 'PO-eUJV6R5xW2284', '{\"en\":\"Sandro\",\"ko\":\"상점\",\"vi\":\"Sandro\"}', NULL, NULL, 10, 2707.99, 1793.25, NULL, '2023-06-24 12:03:35', 59, 318),
(4108, 'PO-Yp5xPuPCf3502', '{\"en\":\"Maje\",\"ko\":\"상점\",\"vi\":\"Maje\"}', NULL, NULL, 10, 2815.99, 1793.505, NULL, '2023-06-24 12:03:35', 59, 316),
(4109, 'PO-Alqj8om354810', '{\"en\":\"Okkio\",\"ko\":\"상점\",\"vi\":\"Okkio\"}', NULL, NULL, 10, 2753.97, 1929.355, NULL, '2023-06-24 12:03:35', 59, 304),
(4110, 'PO-TcBt_o3ch5874', '{\"en\":\"Victoria\'s Secret Flagship\",\"ko\":\"상점\",\"vi\":\"Victoria\'s Secret Flagship\"}', NULL, NULL, 10, 3054.18, 1915.05, NULL, '2023-06-24 12:03:35', 59, 316),
(4111, 'PO-o33NbRwsr9750', '{\"en\":\"Muji\",\"ko\":\"상점\",\"vi\":\"Muji\"}', NULL, NULL, 10, 3488.63, 1992.96, NULL, '2023-06-24 12:03:35', 59, 318),
(4112, 'PO-IEJGjVEmA8882', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3556.710000000001, 1793.23, NULL, '2023-06-24 12:03:35', 59, 329),
(4113, 'PO-w-Sy2QQG20558', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3556.710000000001, 1848.23, NULL, '2023-06-24 12:03:35', 59, 329),
(4114, 'PO-vFTMrUGNE1922', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3556.710000000001, 1903.23, NULL, '2023-06-24 12:03:35', 59, 329),
(4115, 'PO-OOWQ_lzNy9560', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3550.8600000000006, 840.0700000000002, NULL, '2023-06-24 12:03:35', 59, 329),
(4116, 'PO-hHeeFpjvq0875', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3550.8600000000006, 895.0700000000002, NULL, '2023-06-24 12:03:35', 59, 329),
(4117, 'PO-bTah90NKY2178', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3500.8600000000006, 945.0700000000002, NULL, '2023-06-24 12:03:35', 59, 329),
(4118, 'PO-iNFzgrivf3934', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3445.8600000000006, 945.0700000000002, NULL, '2023-06-24 12:03:35', 59, 329),
(4119, 'PO-0vjBSZK2m1959', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3499.2707777276614, 1405.94375643383, NULL, '2023-06-24 12:03:35', 59, 328),
(4120, 'PO-iuhArNOPs3556', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3299.0058190217173, 1451.6695366320846, NULL, '2023-06-24 12:03:35', 59, 328),
(4121, 'PO-eB_UR_xsy4913', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2813.2618520685755, 1630.693744537298, NULL, '2023-06-24 12:03:35', 59, 328),
(4122, 'PO-V-7j2k_iS1291', '{\"en\":\"Bottle Bunker\",\"ko\":\"상점\",\"vi\":\"Bottle Bunker\"}', NULL, NULL, 10, 3604.655751119458, 1553.6838725985851, NULL, '2023-06-24 12:03:35', 59, 325),
(4123, 'PO-t-cElWbvZ3831', '{\"en\":\"Swarovski\",\"ko\":\"상점\",\"vi\":\"Swarovski\"}', NULL, NULL, 10, 3072.025, 1596.875, NULL, '2023-06-24 12:03:35', 59, 319),
(4124, 'PO-5YXycQ-U84989', '{\"en\":\"Marimekko\",\"ko\":\"상점\",\"vi\":\"Marimekko\"}', NULL, NULL, 10, 3076.155, 1506.4300000000003, NULL, '2023-06-24 12:03:35', 59, 316),
(4125, 'PO-Qdtj141IY6195', '{\"en\":\"Paris France/ Make Up For Ever\",\"ko\":\"상점\",\"vi\":\"Paris France / Make Up For Ever\"}', NULL, NULL, 10, 3090.250584415584, 1416.8731648786, NULL, '2023-06-24 12:03:35', 59, 320),
(4126, 'PO-FtCsXKtDP7251', '{\"en\":\"D&G\",\"ko\":\"상점\",\"vi\":\"D&G\"}', NULL, NULL, 10, 3168.645, 1278.13, NULL, '2023-06-24 12:03:35', 59, 320),
(4127, 'PO-su3e7LUxb8365', '{\"en\":\"An Hai Niche\\nPerfume\",\"ko\":\"상점\",\"vi\":\"An Hai Niche Perfume\"}', NULL, NULL, 10, 3177.3190641209144, 1164.65, NULL, '2023-06-24 12:03:35', 59, 320),
(4128, 'PO-d_avyeltP9655', '{\"en\":\"Bvlgari\",\"ko\":\"상점\",\"vi\":\"Bvlgari\"}', NULL, NULL, 10, 3051.3450000000003, 1154.7600000000002, NULL, '2023-06-24 12:03:35', 59, 320),
(4129, 'PO-zUTlw9YgB1753', '{\"en\":\"Pinko\",\"ko\":\"상점\",\"vi\":\"Pinko\"}', NULL, NULL, 10, 2920.1916268514087, 1477.104617773531, NULL, '2023-06-24 12:03:35', 59, 316),
(4130, 'PO-VQL6mjQzJ3099', '{\"en\":\"Max&Co.\",\"ko\":\"상점\",\"vi\":\"Max&Co.\"}', NULL, NULL, 10, 2829.449856665074, 1478.2932281469791, NULL, '2023-06-24 12:03:35', 59, 316),
(4131, 'PO-HmB3T0lph4833', '{\"en\":\"Weekend Max Mara\",\"ko\":\"상점\",\"vi\":\"Weekend Max Mara\"}', NULL, NULL, 10, 2732.215, 1477.01, NULL, '2023-06-24 12:03:35', 59, 316),
(4132, 'PO-UHBxV_Xqo7142', '{\"en\":\"MAC\",\"ko\":\"상점\",\"vi\":\"MAC\"}', NULL, NULL, 10, 2602.3466770186333, 1460.093167701863, NULL, '2023-06-24 12:03:35', 59, 320),
(4133, 'PO-fj7P1xJpR8619', '{\"en\":\"Estee Lauder\",\"ko\":\"상점\",\"vi\":\"Estee Lauder\"}', NULL, NULL, 10, 2513.3900000000003, 1456.905, NULL, '2023-06-24 12:03:35', 59, 320),
(4134, 'PO-maiCYpRQQ9769', '{\"en\":\"Cle De Peau\",\"ko\":\"상점\",\"vi\":\"Cle De Peau\"}', NULL, NULL, 10, 2527.045, 1293.095, NULL, '2023-06-24 12:03:35', 59, 320),
(4135, 'PO-OwJjNGpjV0932', '{\"en\":\"Dior\",\"ko\":\"상점\",\"vi\":\"Dior\"}', NULL, NULL, 10, 2557.945, 1097.735, NULL, '2023-06-24 12:03:35', 59, 320),
(4136, 'PO-v8Ek-6BaZ2155', '{\"en\":\"Shiseido\",\"ko\":\"상점\",\"vi\":\"Shiseido\"}', NULL, NULL, 10, 2726.51, 1133.825, NULL, '2023-06-24 12:03:35', 59, 320),
(4137, 'PO-P4nN3MVAI3136', '{\"en\":\"Maison Margiela\",\"ko\":\"상점\",\"vi\":\"Maison Margiela\"}', NULL, NULL, 10, 2819.7956375593712, 1147.2595019948471, NULL, '2023-06-24 12:03:35', 59, 320),
(4138, 'PO-Qu0Wd4TFB4309', '{\"en\":\"Sulwhasoo\",\"ko\":\"상점\",\"vi\":\"Sulwhasoo\"}', NULL, NULL, 10, 2920.775, 1134.555, NULL, '2023-06-24 12:03:35', 59, 320),
(4139, 'PO-6njAOCmV07301', '{\"en\":\"Banana Republic\",\"ko\":\"상점\",\"vi\":\"Banana Republic\"}', NULL, NULL, 10, 3512.46, 1092.605, NULL, '2023-06-24 12:03:35', 59, 318),
(4140, 'PO-xO1yR1i7n8268', '{\"en\":\"Tommy Hilfiger\",\"ko\":\"상점\",\"vi\":\"Tommy Hilfiger\"}', NULL, NULL, 10, 3524.24, 1185.99, NULL, '2023-06-24 12:03:35', 59, 318),
(4141, 'PO-f0oEdGwgB9547', '{\"en\":\"BIDV Bank\",\"ko\":\"상점\",\"vi\":\"Ngân hàng BIDV\"}', NULL, NULL, 10, 3701.73, 1009.025, NULL, '2023-06-24 12:03:35', 59, 326),
(4142, 'PO-YkcS7E-hv3138', '{\"en\":\"Table Star\",\"ko\":\"상점\",\"vi\":\"Table Star\"}', NULL, NULL, 10, 3576.6170463320464, 659.4396088635214, NULL, '2023-06-24 12:03:35', 59, 302),
(4143, 'PO-JfysfISXz5873', '{\"en\":\"YSL\",\"ko\":\"상점\",\"vi\":\"YSL\"}', NULL, NULL, 10, 2433.86, 795.645, NULL, '2023-06-24 12:03:35', 59, 320),
(4144, 'PO-3cw-CLNFs8203', '{\"en\":\"Kiehl\'s\",\"ko\":\"상점\",\"vi\":\"Kiehl\'s\"}', NULL, NULL, 10, 2531.025, 795.645, NULL, '2023-06-24 12:03:35', 59, 320),
(4145, 'PO-uPAYyMLhh0405', '{\"en\":\"Dyson\",\"ko\":\"상점\",\"vi\":\"Dyson\"}', NULL, NULL, 10, 2755.745, 843.13, NULL, '2023-06-24 12:03:35', 59, 324),
(4146, 'PO-fnUtkfrE62657', '{\"en\":\"Samsung Experience\",\"ko\":\"상점\",\"vi\":\"Samsung Experience\"}', NULL, NULL, 10, 2538.32, 636.1268354430381, NULL, '2023-06-24 12:03:35', 59, 324),
(4147, 'PO-GRjthdDth3641', '{\"en\":\"Uniqlo\",\"ko\":\"상점\",\"vi\":\"Uniqlo\"}', NULL, NULL, 10, 3061.57, 740.465, NULL, '2023-06-24 12:03:35', 59, 318),
(4148, 'PO-AG6s8msNv1104', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1664.4988628132028, 1000.321937332598, NULL, '2023-06-24 12:03:35', 59, 328),
(4149, 'PO-S9Tnyb2wq2425', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1354.3648851214605, 1440.7607427772898, NULL, '2023-06-24 12:03:35', 59, 328),
(4150, 'PO-EwT2r1Wvm3715', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1256.48, 1575.22, NULL, '2023-06-24 12:03:35', 59, 328),
(4151, 'PO-z5yZcAj4Z7990', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2221.374534161491, 1234.5558385093173, NULL, '2023-06-24 12:03:35', 59, 328),
(4152, 'PO-PSkOxBdRx1253', '{\"en\":\"Lacoste\",\"ko\":\"상점\",\"vi\":\"Lacoste\"}', NULL, NULL, 10, 1457.545, 1195.015, NULL, '2023-06-24 12:03:35', 59, 323),
(4153, 'PO-LANIzOlQ32169', '{\"en\":\"Fred Perry\",\"ko\":\"상점\",\"vi\":\"Fred Perry\"}', NULL, NULL, 10, 1583.66, 1183.09, NULL, '2023-06-24 12:03:35', 59, 317),
(4154, 'PO-pBraBtmpT3216', '{\"en\":\"Pandora\",\"ko\":\"상점\",\"vi\":\"Pandora\"}', NULL, NULL, 10, 1484.1086645962737, 1352.075807453416, NULL, '2023-06-24 12:03:35', 59, 319),
(4155, 'PO-DfBf_k-144963', '{\"en\":\"Versace Jeans\\nCouture\",\"ko\":\"상점\",\"vi\":\"Versace Jeans Couture\"}', NULL, NULL, 10, 1544.41, 1479.515, NULL, '2023-06-24 12:03:35', 59, 323),
(4156, 'PO-RAab6m5q66049', '{\"en\":\"Moschino Jeans\",\"ko\":\"상점\",\"vi\":\"Moschino Jeans\"}', NULL, NULL, 10, 1555.685, 1556.86, NULL, '2023-06-24 12:03:35', 59, 323),
(4157, 'PO-nRb31HKbz7150', '{\"en\":\"Tag Heuer\",\"ko\":\"상점\",\"vi\":\"Tag Heuer\"}', NULL, NULL, 10, 1562.81, 1615.41, NULL, '2023-06-24 12:03:35', 59, 319),
(4158, 'PO-inRZXdAU58352', '{\"en\":\"Diesel\",\"ko\":\"상점\",\"vi\":\"Diesel\"}', NULL, NULL, 10, 1715.6078953655035, 1518.3033731485907, NULL, '2023-06-24 12:03:35', 59, 318),
(4159, 'PO-9wdm-1rWB9576', '{\"en\":\"Longines\",\"ko\":\"상점\",\"vi\":\"Longines\"}', NULL, NULL, 10, 1802.205, 1520.245, NULL, '2023-06-24 12:03:35', 59, 319),
(4160, 'PO-X1Mu3q_5F2437', '{\"en\":\"Dsquared2\",\"ko\":\"상점\",\"vi\":\"Dsquared2\"}', NULL, NULL, 10, 2070.5, 1471.445, NULL, '2023-06-24 12:03:35', 59, 323),
(4161, 'PO-NUHV2XAsY5051', '{\"en\":\"Jo Malone\",\"ko\":\"상점\",\"vi\":\"Jo Malone\"}', NULL, NULL, 10, 2099.91, 1256.3850000000002, NULL, '2023-06-24 12:03:35', 59, 320),
(4162, 'PO-13WmX7gXy6245', '{\"en\":\"Chanel\",\"ko\":\"상점\",\"vi\":\"Chanel\"}', NULL, NULL, 10, 2070.505, 1097.735, NULL, '2023-06-24 12:03:35', 59, 320),
(4163, 'PO-JWthzOxa-7463', '{\"en\":\"Sisley\",\"ko\":\"상점\",\"vi\":\"Sisley\"}', NULL, NULL, 10, 1906.35, 1117.685, NULL, '2023-06-24 12:03:35', 59, 320),
(4164, 'PO--pfyFtr4T9151', '{\"en\":\"Clarins\",\"ko\":\"상점\",\"vi\":\"Clarins\"}', NULL, NULL, 10, 1809.69, 1129.1799999999998, NULL, '2023-06-24 12:03:35', 59, 320),
(4165, 'PO-0y2EmY6B-0696', '{\"en\":\"Whoo\",\"ko\":\"상점\",\"vi\":\"Whoo\"}', NULL, NULL, 10, 1714.81, 1139.49, NULL, '2023-06-24 12:03:35', 59, 320),
(4166, 'PO-A04X47GyL7986', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1050.5099999999998, 1840.03, NULL, '2023-06-24 12:03:35', 59, 329),
(4167, 'PO-sOxaHEdFZ1679', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 1834.69, 1295.79, NULL, '2023-06-24 12:03:35', 59, 309),
(4168, 'PO-LlAh1PUjX2905', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 1834.69, 1350.79, NULL, '2023-06-24 12:03:35', 59, 309),
(4169, 'PO-zXOgJ6HcU9307', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 1932.31, 1295.79, NULL, '2023-06-24 12:03:35', 59, 312),
(4170, 'PO-Pp6E3E3Bk7531', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 1932.31, 1350.79, NULL, '2023-06-24 12:03:35', 59, 313),
(4171, 'PO-uVnggEmEJ9318', '{\"en\":\"In for\\nma\\ntion\",\"ko\":\"상점\",\"vi\":\"Quầy thông\\ntin\"}', NULL, NULL, 10, 2262.441540125798, 1234.09, NULL, '2023-06-24 12:03:35', 59, 315),
(4172, 'PO-r4nwFdurf7863', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2403.8900000000003, 1366.1800000000003, NULL, '2023-06-24 12:03:35', 59, 329),
(4173, 'PO-TRd6Ruv2J8809', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2403.8900000000003, 1421.1800000000003, NULL, '2023-06-24 12:03:35', 59, 329),
(4174, 'PO-GjVExdSHt9378', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 2811.4, 1292.23, NULL, '2023-06-24 12:03:35', 59, 309),
(4175, 'PO-DLlPnNYEi0701', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 2811.4, 1347.23, NULL, '2023-06-24 12:03:35', 59, 309),
(4176, 'PO-wcnvhfVB42495', '{\"en\":\"Baby lounge\",\"ko\":\"NO NAME\",\"vi\":\"Phòng mẹ & bé\"}', NULL, NULL, 10, 2703.03, 1292.23, NULL, '2023-06-24 12:03:35', 59, 312),
(4177, 'PO-R_5PW65pG0748', '{\"en\":\"Rest area\",\"ko\":\"상점\",\"vi\":\"Khu nghỉ\\nchân\"}', NULL, NULL, 10, 2703.03, 1347.23, NULL, '2023-06-24 12:03:35', 59, 313),
(4178, 'PO-mciGEflOp1648', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 1370.3737891228106, 2169.9908897201803, NULL, '2023-06-24 12:03:35', 59, 331),
(4179, 'PO-eMwbJUAtJ4097', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 2323.5904164576878, 1951.391855664368, NULL, '2023-06-24 12:03:35', 59, 331),
(4180, 'PO-TtFQMPbIs7950', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 3266.242967095038, 2217.2769188596194, NULL, '2023-06-24 12:03:35', 59, 331),
(4181, 'PO-P4S8INN1Z2496', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 3471.8103464819837, 428.0520928466019, NULL, '2023-06-24 12:03:35', 59, 331),
(4182, 'PO---sacJhMe5343', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 2314.537267117208, 427.603989776891, NULL, '2023-06-24 12:03:35', 59, 331),
(4183, 'PO-bsWGzBoii7769', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 1059.6850291154026, 624.9460248819606, NULL, '2023-06-24 12:03:35', 59, 331),
(4184, 'PO-v7o4W2DzH9257', '{\"en\":\"Entrance\",\"ko\":\"NO NAME\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 2134.1610109536973, 1973.426161986259, NULL, '2023-06-24 12:03:35', 59, 331),
(4185, 'PO-6v8RKGX0X1287', '{\"en\":\"Entrance\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 3713.8290619209297, 1256.664976749062, NULL, '2023-06-24 12:03:35', 59, 331),
(4186, 'PO-lrhkzw5YH2976', '{\"en\":\"Office Ent.\",\"vi\":\"Lối vào văn phòng\"}', NULL, NULL, 10, 3614.383252965305, 1258.282199244849, NULL, '2023-06-24 12:03:35', 59, 331),
(4187, 'PO-IFQu5efGK9220', '{\"en\":\"Entrance\",\"vi\":\"Lối ra vào\"}', NULL, NULL, 10, 1075.9551966861038, 1290.7810084394794, NULL, '2023-06-24 12:03:35', 59, 331),
(4188, 'PO-Yzrol15k20695', '{\"en\":\"Hotel Ent.\",\"vi\":\"Lối vào khách sạn\"}', NULL, NULL, 10, 1164.6207355456927, 1290.930277023418, NULL, '2023-06-24 12:03:35', 59, 331),
(4189, 'PO-m-0rcgLGT2226', '{\"en\":\"Office\",\"vi\":\"Văn phòng\"}', NULL, NULL, 10, 3969.022209056287, 1256.580774439271, NULL, '2023-06-24 12:03:35', 59, 326),
(4190, 'PO-DdvZz9Llz8276', '{\"en\":\"Hotel\",\"vi\":\"Khách sạn\"}', NULL, NULL, 10, 764.608093261719, 1441.8730773925754, NULL, '2023-06-24 12:03:35', 59, 326),
(4191, 'PO-x7iUKMHac4956', '{\"en\":\"L\'Occitane\",\"vi\":\"L\'Occitane\"}', NULL, NULL, 10, 2635.49, 805.05, NULL, '2023-06-24 12:03:35', 59, 320),
(4192, 'PO-OCWhT2vif3356', '{\"en\":\"Hermes\",\"vi\":\"Hermes\"}', NULL, NULL, 10, 2070.505, 1363.32, NULL, '2023-06-24 12:03:35', 59, 320),
(4193, 'PO-yRAer02Zu5277', '{\"en\":\"Karl Lagerfeld\",\"vi\":\"Karl Lagerfeld\"}', NULL, NULL, 10, 1897.2254901960785, 1477.6342156862745, NULL, '2023-06-24 12:03:35', 59, 323),
(4194, 'PO-jcPe67U3L9225', '{\"en\":\"Lotte Mart\",\"ko\":\"상점\",\"vi\":\"Siêu thị Lotte Mart\"}', NULL, NULL, 10, 1730.2660869565198, 1363.8916770186336, NULL, '2023-06-24 12:03:35', 60, 326),
(4195, 'PO-agArvccAg2052', '{\"en\":\"Aquarium\",\"ko\":\"상점\",\"vi\":\"Thủy cung\"}', NULL, NULL, 10, 2904.574503288821, 1581.7348489394576, NULL, '2023-06-24 12:03:35', 60, 326),
(4196, 'PO-gVc-X39cE5241', '{\"en\":\"Phar ma\\ncity\",\"ko\":\"상점\",\"vi\":\"Nhà thuốc\\nPharma\\ncity\"}', NULL, NULL, 10, 2155.5950000000003, 1235.71, NULL, '2023-06-24 12:03:35', 60, 326),
(4197, 'PO-VxSTeKIDC7135', '{\"en\":\"Phuc Long\",\"ko\":\"상점\",\"vi\":\"Phúc Long\"}', NULL, NULL, 10, 2267.21, 1235.71, NULL, '2023-06-24 12:03:35', 60, 304),
(4198, 'PO-0YFIbWm_i2516', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2207.70695188653, 1228.8644141095751, NULL, '2023-06-24 12:03:35', 60, 328),
(4199, 'PO-3DEjI6TPj6458', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 2124.19, 1743.15, NULL, '2023-06-24 12:03:35', 60, 328),
(4200, 'PO-q-Dm5o1J49624', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2422.17, 1377.06, NULL, '2023-06-24 12:03:35', 60, 329),
(4201, 'PO-QIATS5vXZ1299', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 2422.17, 1432.06, NULL, '2023-06-24 12:03:35', 60, 329),
(4202, 'PO-G9CnbQ2rn7954', '{\"en\":\"Restroom\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh\"}', NULL, NULL, 10, 2457.72, 788.34, NULL, '2023-06-24 12:03:35', 60, 309),
(4203, 'PO-X7DPUpjmJ0811', '{\"en\":\"Bakery\",\"ko\":\"상점\",\"vi\":\"Tiệm Bánh mì\"}', NULL, NULL, 10, 2408.9300000000003, 864.665, NULL, '2023-06-24 12:03:35', 60, 305),
(4204, 'PO-a8lbIZL6n2992', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3515.7300000000005, 923.7000000000004, NULL, '2023-06-24 12:03:35', 60, 329),
(4205, 'PO-xCRckcP-P4026', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3460.7300000000005, 923.7000000000004, NULL, '2023-06-24 12:03:35', 60, 329),
(4206, 'PO-Hx0KFVj6d0180', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 3510.73, 1426.94, NULL, '2023-06-24 12:03:35', 60, 328),
(4207, 'PO-BKbNdY-4Q8628', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1033.4, 1705.8199999999997, NULL, '2023-06-24 12:03:35', 60, 329),
(4208, 'PO-7pFqb_K930432', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 978.4, 1705.82, NULL, '2023-06-24 12:03:35', 60, 329),
(4209, 'PO-eS5ek7Sv-1474', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1032.4974457715332, 1806.29, NULL, '2023-06-24 12:03:35', 60, 329),
(4210, 'PO-m0G6i2fPG2556', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 978.3999999999996, 1861.29, NULL, '2023-06-24 12:03:35', 60, 329),
(4211, 'PO-kbpbCJ6tH3696', '{\"en\":\"Elevator\",\"ko\":\"NO NAME\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 1033.3999999999996, 1861.29, NULL, '2023-06-24 12:03:35', 60, 329),
(4212, 'PO-GlNNGKkgQ7933', '{\"en\":\"Escalator\",\"ko\":\"NO NAME\",\"vi\":\"Thang cuốn\"}', NULL, NULL, 10, 1210.29, 1640.82, NULL, '2023-06-24 12:03:35', 60, 328),
(4213, 'PO-OK-LKYC8c6497', '{\"en\":\"Parking\",\"ko\":\"NO NAME\",\"vi\":\"Bãi đỗ xe\"}', NULL, NULL, 10, 2197.180203502837, 2466.040743357548, NULL, '2023-06-24 12:03:35', 60, 330),
(4214, 'PO-cj9BaEbSa3229', '{\"en\":\"Restroom (men)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nam\"}', NULL, NULL, 10, 923.4, 1861.29, NULL, '2023-06-24 12:03:35', 60, 309),
(4215, 'PO-jrkUMNIYe5396', '{\"en\":\"Restroom (women)\",\"ko\":\"NO NAME\",\"vi\":\"Nhà vệ sinh nữ\"}', NULL, NULL, 10, 868.4000000000001, 1861.29, NULL, '2023-06-24 12:03:35', 60, 309),
(4216, 'PO-1RKRZtGZF7708', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.30151367188, 868.700017345039, NULL, '2023-06-24 12:03:35', 60, 329),
(4217, 'PO-PYtemielz9433', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.30151367188, 923.700017345039, NULL, '2023-06-24 12:03:35', 60, 329),
(4218, 'PO-VWZkJB1iK5116', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.3017578125, 1812.47607027651, NULL, '2023-06-24 12:03:35', 60, 329),
(4219, 'PO-Es-43ylkf6675', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.3017578125, 1867.47607027651, NULL, '2023-06-24 12:03:35', 60, 329),
(4220, 'PO-bVonVOQSa8546', '{\"en\":\"Elevator\",\"vi\":\"Thang máy\"}', NULL, NULL, 10, 3603.3017578125, 1922.476070276505, NULL, '2023-06-24 12:03:35', 60, 329);

-- --------------------------------------------------------

--
-- Table structure for table `poi_tags`
--

CREATE TABLE `poi_tags` (
  `poi_id` bigint(20) NOT NULL,
  `tag_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `screens`
--

CREATE TABLE `screens` (
  `id` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `seq_code` varchar(50) DEFAULT NULL,
  `type` enum('0','1','2') NOT NULL DEFAULT '1',
  `duration` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `start_date` datetime NOT NULL DEFAULT current_timestamp(),
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `screens`
--

INSERT INTO `screens` (`id`, `title`, `seq_code`, `type`, `duration`, `order`, `start_date`, `end_date`, `created_at`) VALUES
(110, 'sffgdf', '062cd11b-bdf8-411f-aa3a-c6bcc5e2b41c', '2', 5000, 0, '2023-06-22 17:00:00', '2023-06-27 17:00:00', '2023-06-24 12:03:35');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) NOT NULL,
  `content` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_poi`
--
ALTER TABLE `event_poi`
  ADD PRIMARY KEY (`event_id`,`poi_id`),
  ADD KEY `IDX_9e293249b929512154372a59b0` (`event_id`),
  ADD KEY `IDX_ab55a4f125dd5c9adc548a214d` (`poi_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `floors`
--
ALTER TABLE `floors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD PRIMARY KEY (`menu_id`,`category_id`),
  ADD KEY `IDX_0da59e0a8c0bf70a3a7f532c9e` (`menu_id`),
  ADD KEY `IDX_bd99dc53718848aacc73d4fcfe` (`category_id`);

--
-- Indexes for table `pois`
--
ALTER TABLE `pois`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_cadee39eba348ec7a5a19858c61` (`floor_id`),
  ADD KEY `FK_fe53850de9fbb356d34febc90a3` (`category_id`);

--
-- Indexes for table `poi_tags`
--
ALTER TABLE `poi_tags`
  ADD PRIMARY KEY (`poi_id`,`tag_id`),
  ADD KEY `IDX_5e816597d0528a282c29655ed6` (`poi_id`),
  ADD KEY `IDX_c3f2a88068f705698d0efaacd4` (`tag_id`);

--
-- Indexes for table `screens`
--
ALTER TABLE `screens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=751;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event_poi`
--
ALTER TABLE `event_poi`
  ADD CONSTRAINT `FK_9e293249b929512154372a59b08` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_ab55a4f125dd5c9adc548a214d3` FOREIGN KEY (`poi_id`) REFERENCES `pois` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD CONSTRAINT `FK_0da59e0a8c0bf70a3a7f532c9e0` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_bd99dc53718848aacc73d4fcfe1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pois`
--
ALTER TABLE `pois`
  ADD CONSTRAINT `FK_cadee39eba348ec7a5a19858c61` FOREIGN KEY (`floor_id`) REFERENCES `floors` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_fe53850de9fbb356d34febc90a3` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `poi_tags`
--
ALTER TABLE `poi_tags`
  ADD CONSTRAINT `FK_5e816597d0528a282c29655ed6a` FOREIGN KEY (`poi_id`) REFERENCES `pois` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_c3f2a88068f705698d0efaacd4d` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
